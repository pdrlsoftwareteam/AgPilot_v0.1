#pragma once
// MESSAGE NO_FLY_ZONE PACKING

#define MAVLINK_MSG_ID_NO_FLY_ZONE 94


typedef struct __mavlink_no_fly_zone_t {
 uint64_t time_usec; /*< [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.*/
 double lat[12]; /*<  Latitude of centre of circle or Latitude array of polygon.*/
 double lng[12]; /*<  Longitude of centre of circle or longitude array of polygon.*/
 uint32_t radius_cm; /*<  Radius of circle.*/
 uint16_t alt_max; /*<  Maximum altitude flying allowed*/
 uint8_t id; /*<   No fly zone circle id.*/
 uint8_t area_type; /*<  Which type of area circle/polygon*/
 uint8_t zone_type; /*<  Which zone? yellow/red*/
} mavlink_no_fly_zone_t;

#define MAVLINK_MSG_ID_NO_FLY_ZONE_LEN 209
#define MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN 209
#define MAVLINK_MSG_ID_94_LEN 209
#define MAVLINK_MSG_ID_94_MIN_LEN 209

#define MAVLINK_MSG_ID_NO_FLY_ZONE_CRC 84
#define MAVLINK_MSG_ID_94_CRC 84

#define MAVLINK_MSG_NO_FLY_ZONE_FIELD_LAT_LEN 12
#define MAVLINK_MSG_NO_FLY_ZONE_FIELD_LNG_LEN 12

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_NO_FLY_ZONE { \
    94, \
    "NO_FLY_ZONE", \
    8, \
    {  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_no_fly_zone_t, time_usec) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 206, offsetof(mavlink_no_fly_zone_t, id) }, \
         { "area_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 207, offsetof(mavlink_no_fly_zone_t, area_type) }, \
         { "zone_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 208, offsetof(mavlink_no_fly_zone_t, zone_type) }, \
         { "lat", NULL, MAVLINK_TYPE_DOUBLE, 12, 8, offsetof(mavlink_no_fly_zone_t, lat) }, \
         { "lng", NULL, MAVLINK_TYPE_DOUBLE, 12, 104, offsetof(mavlink_no_fly_zone_t, lng) }, \
         { "radius_cm", NULL, MAVLINK_TYPE_UINT32_T, 0, 200, offsetof(mavlink_no_fly_zone_t, radius_cm) }, \
         { "alt_max", NULL, MAVLINK_TYPE_UINT16_T, 0, 204, offsetof(mavlink_no_fly_zone_t, alt_max) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_NO_FLY_ZONE { \
    "NO_FLY_ZONE", \
    8, \
    {  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_no_fly_zone_t, time_usec) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 206, offsetof(mavlink_no_fly_zone_t, id) }, \
         { "area_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 207, offsetof(mavlink_no_fly_zone_t, area_type) }, \
         { "zone_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 208, offsetof(mavlink_no_fly_zone_t, zone_type) }, \
         { "lat", NULL, MAVLINK_TYPE_DOUBLE, 12, 8, offsetof(mavlink_no_fly_zone_t, lat) }, \
         { "lng", NULL, MAVLINK_TYPE_DOUBLE, 12, 104, offsetof(mavlink_no_fly_zone_t, lng) }, \
         { "radius_cm", NULL, MAVLINK_TYPE_UINT32_T, 0, 200, offsetof(mavlink_no_fly_zone_t, radius_cm) }, \
         { "alt_max", NULL, MAVLINK_TYPE_UINT16_T, 0, 204, offsetof(mavlink_no_fly_zone_t, alt_max) }, \
         } \
}
#endif

/**
 * @brief Pack a no_fly_zone message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 * @param id   No fly zone circle id.
 * @param area_type  Which type of area circle/polygon
 * @param zone_type  Which zone? yellow/red
 * @param lat  Latitude of centre of circle or Latitude array of polygon.
 * @param lng  Longitude of centre of circle or longitude array of polygon.
 * @param radius_cm  Radius of circle.
 * @param alt_max  Maximum altitude flying allowed
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_no_fly_zone_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint64_t time_usec, uint8_t id, uint8_t area_type, uint8_t zone_type, const double *lat, const double *lng, uint32_t radius_cm, uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NO_FLY_ZONE_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_uint32_t(buf, 200, radius_cm);
    _mav_put_uint16_t(buf, 204, alt_max);
    _mav_put_uint8_t(buf, 206, id);
    _mav_put_uint8_t(buf, 207, area_type);
    _mav_put_uint8_t(buf, 208, zone_type);
    _mav_put_double_array(buf, 8, lat, 12);
    _mav_put_double_array(buf, 104, lng, 12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN);
#else
    mavlink_no_fly_zone_t packet;
    packet.time_usec = time_usec;
    packet.radius_cm = radius_cm;
    packet.alt_max = alt_max;
    packet.id = id;
    packet.area_type = area_type;
    packet.zone_type = zone_type;
    mav_array_memcpy(packet.lat, lat, sizeof(double)*12);
    mav_array_memcpy(packet.lng, lng, sizeof(double)*12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NO_FLY_ZONE;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
}

/**
 * @brief Pack a no_fly_zone message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 * @param id   No fly zone circle id.
 * @param area_type  Which type of area circle/polygon
 * @param zone_type  Which zone? yellow/red
 * @param lat  Latitude of centre of circle or Latitude array of polygon.
 * @param lng  Longitude of centre of circle or longitude array of polygon.
 * @param radius_cm  Radius of circle.
 * @param alt_max  Maximum altitude flying allowed
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_no_fly_zone_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint64_t time_usec,uint8_t id,uint8_t area_type,uint8_t zone_type,const double *lat,const double *lng,uint32_t radius_cm,uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NO_FLY_ZONE_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_uint32_t(buf, 200, radius_cm);
    _mav_put_uint16_t(buf, 204, alt_max);
    _mav_put_uint8_t(buf, 206, id);
    _mav_put_uint8_t(buf, 207, area_type);
    _mav_put_uint8_t(buf, 208, zone_type);
    _mav_put_double_array(buf, 8, lat, 12);
    _mav_put_double_array(buf, 104, lng, 12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN);
#else
    mavlink_no_fly_zone_t packet;
    packet.time_usec = time_usec;
    packet.radius_cm = radius_cm;
    packet.alt_max = alt_max;
    packet.id = id;
    packet.area_type = area_type;
    packet.zone_type = zone_type;
    mav_array_memcpy(packet.lat, lat, sizeof(double)*12);
    mav_array_memcpy(packet.lng, lng, sizeof(double)*12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NO_FLY_ZONE;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
}

/**
 * @brief Encode a no_fly_zone struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param no_fly_zone C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_no_fly_zone_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_no_fly_zone_t* no_fly_zone)
{
    return mavlink_msg_no_fly_zone_pack(system_id, component_id, msg, no_fly_zone->time_usec, no_fly_zone->id, no_fly_zone->area_type, no_fly_zone->zone_type, no_fly_zone->lat, no_fly_zone->lng, no_fly_zone->radius_cm, no_fly_zone->alt_max);
}

/**
 * @brief Encode a no_fly_zone struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param no_fly_zone C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_no_fly_zone_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_no_fly_zone_t* no_fly_zone)
{
    return mavlink_msg_no_fly_zone_pack_chan(system_id, component_id, chan, msg, no_fly_zone->time_usec, no_fly_zone->id, no_fly_zone->area_type, no_fly_zone->zone_type, no_fly_zone->lat, no_fly_zone->lng, no_fly_zone->radius_cm, no_fly_zone->alt_max);
}

/**
 * @brief Send a no_fly_zone message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 * @param id   No fly zone circle id.
 * @param area_type  Which type of area circle/polygon
 * @param zone_type  Which zone? yellow/red
 * @param lat  Latitude of centre of circle or Latitude array of polygon.
 * @param lng  Longitude of centre of circle or longitude array of polygon.
 * @param radius_cm  Radius of circle.
 * @param alt_max  Maximum altitude flying allowed
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_no_fly_zone_send(mavlink_channel_t chan, uint64_t time_usec, uint8_t id, uint8_t area_type, uint8_t zone_type, const double *lat, const double *lng, uint32_t radius_cm, uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NO_FLY_ZONE_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_uint32_t(buf, 200, radius_cm);
    _mav_put_uint16_t(buf, 204, alt_max);
    _mav_put_uint8_t(buf, 206, id);
    _mav_put_uint8_t(buf, 207, area_type);
    _mav_put_uint8_t(buf, 208, zone_type);
    _mav_put_double_array(buf, 8, lat, 12);
    _mav_put_double_array(buf, 104, lng, 12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE, buf, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
#else
    mavlink_no_fly_zone_t packet;
    packet.time_usec = time_usec;
    packet.radius_cm = radius_cm;
    packet.alt_max = alt_max;
    packet.id = id;
    packet.area_type = area_type;
    packet.zone_type = zone_type;
    mav_array_memcpy(packet.lat, lat, sizeof(double)*12);
    mav_array_memcpy(packet.lng, lng, sizeof(double)*12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE, (const char *)&packet, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
#endif
}

/**
 * @brief Send a no_fly_zone message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_no_fly_zone_send_struct(mavlink_channel_t chan, const mavlink_no_fly_zone_t* no_fly_zone)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_no_fly_zone_send(chan, no_fly_zone->time_usec, no_fly_zone->id, no_fly_zone->area_type, no_fly_zone->zone_type, no_fly_zone->lat, no_fly_zone->lng, no_fly_zone->radius_cm, no_fly_zone->alt_max);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE, (const char *)no_fly_zone, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
#endif
}

#if MAVLINK_MSG_ID_NO_FLY_ZONE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_no_fly_zone_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, uint8_t id, uint8_t area_type, uint8_t zone_type, const double *lat, const double *lng, uint32_t radius_cm, uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_uint32_t(buf, 200, radius_cm);
    _mav_put_uint16_t(buf, 204, alt_max);
    _mav_put_uint8_t(buf, 206, id);
    _mav_put_uint8_t(buf, 207, area_type);
    _mav_put_uint8_t(buf, 208, zone_type);
    _mav_put_double_array(buf, 8, lat, 12);
    _mav_put_double_array(buf, 104, lng, 12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE, buf, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
#else
    mavlink_no_fly_zone_t *packet = (mavlink_no_fly_zone_t *)msgbuf;
    packet->time_usec = time_usec;
    packet->radius_cm = radius_cm;
    packet->alt_max = alt_max;
    packet->id = id;
    packet->area_type = area_type;
    packet->zone_type = zone_type;
    mav_array_memcpy(packet->lat, lat, sizeof(double)*12);
    mav_array_memcpy(packet->lng, lng, sizeof(double)*12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE, (const char *)packet, MAVLINK_MSG_ID_NO_FLY_ZONE_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_CRC);
#endif
}
#endif

#endif

// MESSAGE NO_FLY_ZONE UNPACKING


/**
 * @brief Get field time_usec from no_fly_zone message
 *
 * @return [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 */
static inline uint64_t mavlink_msg_no_fly_zone_get_time_usec(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  0);
}

/**
 * @brief Get field id from no_fly_zone message
 *
 * @return   No fly zone circle id.
 */
static inline uint8_t mavlink_msg_no_fly_zone_get_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  206);
}

/**
 * @brief Get field area_type from no_fly_zone message
 *
 * @return  Which type of area circle/polygon
 */
static inline uint8_t mavlink_msg_no_fly_zone_get_area_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  207);
}

/**
 * @brief Get field zone_type from no_fly_zone message
 *
 * @return  Which zone? yellow/red
 */
static inline uint8_t mavlink_msg_no_fly_zone_get_zone_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  208);
}

/**
 * @brief Get field lat from no_fly_zone message
 *
 * @return  Latitude of centre of circle or Latitude array of polygon.
 */
static inline uint16_t mavlink_msg_no_fly_zone_get_lat(const mavlink_message_t* msg, double *lat)
{
    return _MAV_RETURN_double_array(msg, lat, 12,  8);
}

/**
 * @brief Get field lng from no_fly_zone message
 *
 * @return  Longitude of centre of circle or longitude array of polygon.
 */
static inline uint16_t mavlink_msg_no_fly_zone_get_lng(const mavlink_message_t* msg, double *lng)
{
    return _MAV_RETURN_double_array(msg, lng, 12,  104);
}

/**
 * @brief Get field radius_cm from no_fly_zone message
 *
 * @return  Radius of circle.
 */
static inline uint32_t mavlink_msg_no_fly_zone_get_radius_cm(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  200);
}

/**
 * @brief Get field alt_max from no_fly_zone message
 *
 * @return  Maximum altitude flying allowed
 */
static inline uint16_t mavlink_msg_no_fly_zone_get_alt_max(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  204);
}

/**
 * @brief Decode a no_fly_zone message into a struct
 *
 * @param msg The message to decode
 * @param no_fly_zone C-struct to decode the message contents into
 */
static inline void mavlink_msg_no_fly_zone_decode(const mavlink_message_t* msg, mavlink_no_fly_zone_t* no_fly_zone)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    no_fly_zone->time_usec = mavlink_msg_no_fly_zone_get_time_usec(msg);
    mavlink_msg_no_fly_zone_get_lat(msg, no_fly_zone->lat);
    mavlink_msg_no_fly_zone_get_lng(msg, no_fly_zone->lng);
    no_fly_zone->radius_cm = mavlink_msg_no_fly_zone_get_radius_cm(msg);
    no_fly_zone->alt_max = mavlink_msg_no_fly_zone_get_alt_max(msg);
    no_fly_zone->id = mavlink_msg_no_fly_zone_get_id(msg);
    no_fly_zone->area_type = mavlink_msg_no_fly_zone_get_area_type(msg);
    no_fly_zone->zone_type = mavlink_msg_no_fly_zone_get_zone_type(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_NO_FLY_ZONE_LEN? msg->len : MAVLINK_MSG_ID_NO_FLY_ZONE_LEN;
        memset(no_fly_zone, 0, MAVLINK_MSG_ID_NO_FLY_ZONE_LEN);
    memcpy(no_fly_zone, _MAV_PAYLOAD(msg), len);
#endif
}
