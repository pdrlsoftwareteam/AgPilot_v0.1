#pragma once
// MESSAGE NO_FLY_ZONE_POLYGON PACKING

#define MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON 95


typedef struct __mavlink_no_fly_zone_polygon_t {
 uint64_t time_usec; /*< [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.*/
 double lat; /*<  Latitude of centre of circle or Latitude array of polygon.*/
 double lng; /*<  Longitude of centre of circle or longitude array of polygon.*/
 uint16_t total_point; /*<  Which type of area circle/polygon*/
 uint16_t curr_index; /*<  current index of current position in polygon*/
 uint16_t alt_max; /*<  Maximum altitude flying allowed*/
 uint8_t id; /*<   No. fly zone circle id.*/
 uint8_t zone_type; /*<  Which zone? yellow/red*/
} mavlink_no_fly_zone_polygon_t;

#define MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN 32
#define MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN 32
#define MAVLINK_MSG_ID_95_LEN 32
#define MAVLINK_MSG_ID_95_MIN_LEN 32

#define MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC 44
#define MAVLINK_MSG_ID_95_CRC 44



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_NO_FLY_ZONE_POLYGON { \
    95, \
    "NO_FLY_ZONE_POLYGON", \
    8, \
    {  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_no_fly_zone_polygon_t, time_usec) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 30, offsetof(mavlink_no_fly_zone_polygon_t, id) }, \
         { "total_point", NULL, MAVLINK_TYPE_UINT16_T, 0, 24, offsetof(mavlink_no_fly_zone_polygon_t, total_point) }, \
         { "curr_index", NULL, MAVLINK_TYPE_UINT16_T, 0, 26, offsetof(mavlink_no_fly_zone_polygon_t, curr_index) }, \
         { "lat", NULL, MAVLINK_TYPE_DOUBLE, 0, 8, offsetof(mavlink_no_fly_zone_polygon_t, lat) }, \
         { "lng", NULL, MAVLINK_TYPE_DOUBLE, 0, 16, offsetof(mavlink_no_fly_zone_polygon_t, lng) }, \
         { "zone_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 31, offsetof(mavlink_no_fly_zone_polygon_t, zone_type) }, \
         { "alt_max", NULL, MAVLINK_TYPE_UINT16_T, 0, 28, offsetof(mavlink_no_fly_zone_polygon_t, alt_max) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_NO_FLY_ZONE_POLYGON { \
    "NO_FLY_ZONE_POLYGON", \
    8, \
    {  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_no_fly_zone_polygon_t, time_usec) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 30, offsetof(mavlink_no_fly_zone_polygon_t, id) }, \
         { "total_point", NULL, MAVLINK_TYPE_UINT16_T, 0, 24, offsetof(mavlink_no_fly_zone_polygon_t, total_point) }, \
         { "curr_index", NULL, MAVLINK_TYPE_UINT16_T, 0, 26, offsetof(mavlink_no_fly_zone_polygon_t, curr_index) }, \
         { "lat", NULL, MAVLINK_TYPE_DOUBLE, 0, 8, offsetof(mavlink_no_fly_zone_polygon_t, lat) }, \
         { "lng", NULL, MAVLINK_TYPE_DOUBLE, 0, 16, offsetof(mavlink_no_fly_zone_polygon_t, lng) }, \
         { "zone_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 31, offsetof(mavlink_no_fly_zone_polygon_t, zone_type) }, \
         { "alt_max", NULL, MAVLINK_TYPE_UINT16_T, 0, 28, offsetof(mavlink_no_fly_zone_polygon_t, alt_max) }, \
         } \
}
#endif

/**
 * @brief Pack a no_fly_zone_polygon message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 * @param id   No. fly zone circle id.
 * @param total_point  Which type of area circle/polygon
 * @param curr_index  current index of current position in polygon
 * @param lat  Latitude of centre of circle or Latitude array of polygon.
 * @param lng  Longitude of centre of circle or longitude array of polygon.
 * @param zone_type  Which zone? yellow/red
 * @param alt_max  Maximum altitude flying allowed
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint64_t time_usec, uint8_t id, uint16_t total_point, uint16_t curr_index, double lat, double lng, uint8_t zone_type, uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_double(buf, 8, lat);
    _mav_put_double(buf, 16, lng);
    _mav_put_uint16_t(buf, 24, total_point);
    _mav_put_uint16_t(buf, 26, curr_index);
    _mav_put_uint16_t(buf, 28, alt_max);
    _mav_put_uint8_t(buf, 30, id);
    _mav_put_uint8_t(buf, 31, zone_type);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN);
#else
    mavlink_no_fly_zone_polygon_t packet;
    packet.time_usec = time_usec;
    packet.lat = lat;
    packet.lng = lng;
    packet.total_point = total_point;
    packet.curr_index = curr_index;
    packet.alt_max = alt_max;
    packet.id = id;
    packet.zone_type = zone_type;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
}

/**
 * @brief Pack a no_fly_zone_polygon message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 * @param id   No. fly zone circle id.
 * @param total_point  Which type of area circle/polygon
 * @param curr_index  current index of current position in polygon
 * @param lat  Latitude of centre of circle or Latitude array of polygon.
 * @param lng  Longitude of centre of circle or longitude array of polygon.
 * @param zone_type  Which zone? yellow/red
 * @param alt_max  Maximum altitude flying allowed
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint64_t time_usec,uint8_t id,uint16_t total_point,uint16_t curr_index,double lat,double lng,uint8_t zone_type,uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_double(buf, 8, lat);
    _mav_put_double(buf, 16, lng);
    _mav_put_uint16_t(buf, 24, total_point);
    _mav_put_uint16_t(buf, 26, curr_index);
    _mav_put_uint16_t(buf, 28, alt_max);
    _mav_put_uint8_t(buf, 30, id);
    _mav_put_uint8_t(buf, 31, zone_type);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN);
#else
    mavlink_no_fly_zone_polygon_t packet;
    packet.time_usec = time_usec;
    packet.lat = lat;
    packet.lng = lng;
    packet.total_point = total_point;
    packet.curr_index = curr_index;
    packet.alt_max = alt_max;
    packet.id = id;
    packet.zone_type = zone_type;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
}

/**
 * @brief Encode a no_fly_zone_polygon struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param no_fly_zone_polygon C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_no_fly_zone_polygon_t* no_fly_zone_polygon)
{
    return mavlink_msg_no_fly_zone_polygon_pack(system_id, component_id, msg, no_fly_zone_polygon->time_usec, no_fly_zone_polygon->id, no_fly_zone_polygon->total_point, no_fly_zone_polygon->curr_index, no_fly_zone_polygon->lat, no_fly_zone_polygon->lng, no_fly_zone_polygon->zone_type, no_fly_zone_polygon->alt_max);
}

/**
 * @brief Encode a no_fly_zone_polygon struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param no_fly_zone_polygon C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_no_fly_zone_polygon_t* no_fly_zone_polygon)
{
    return mavlink_msg_no_fly_zone_polygon_pack_chan(system_id, component_id, chan, msg, no_fly_zone_polygon->time_usec, no_fly_zone_polygon->id, no_fly_zone_polygon->total_point, no_fly_zone_polygon->curr_index, no_fly_zone_polygon->lat, no_fly_zone_polygon->lng, no_fly_zone_polygon->zone_type, no_fly_zone_polygon->alt_max);
}

/**
 * @brief Send a no_fly_zone_polygon message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 * @param id   No. fly zone circle id.
 * @param total_point  Which type of area circle/polygon
 * @param curr_index  current index of current position in polygon
 * @param lat  Latitude of centre of circle or Latitude array of polygon.
 * @param lng  Longitude of centre of circle or longitude array of polygon.
 * @param zone_type  Which zone? yellow/red
 * @param alt_max  Maximum altitude flying allowed
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_no_fly_zone_polygon_send(mavlink_channel_t chan, uint64_t time_usec, uint8_t id, uint16_t total_point, uint16_t curr_index, double lat, double lng, uint8_t zone_type, uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_double(buf, 8, lat);
    _mav_put_double(buf, 16, lng);
    _mav_put_uint16_t(buf, 24, total_point);
    _mav_put_uint16_t(buf, 26, curr_index);
    _mav_put_uint16_t(buf, 28, alt_max);
    _mav_put_uint8_t(buf, 30, id);
    _mav_put_uint8_t(buf, 31, zone_type);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON, buf, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
#else
    mavlink_no_fly_zone_polygon_t packet;
    packet.time_usec = time_usec;
    packet.lat = lat;
    packet.lng = lng;
    packet.total_point = total_point;
    packet.curr_index = curr_index;
    packet.alt_max = alt_max;
    packet.id = id;
    packet.zone_type = zone_type;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON, (const char *)&packet, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
#endif
}

/**
 * @brief Send a no_fly_zone_polygon message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_no_fly_zone_polygon_send_struct(mavlink_channel_t chan, const mavlink_no_fly_zone_polygon_t* no_fly_zone_polygon)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_no_fly_zone_polygon_send(chan, no_fly_zone_polygon->time_usec, no_fly_zone_polygon->id, no_fly_zone_polygon->total_point, no_fly_zone_polygon->curr_index, no_fly_zone_polygon->lat, no_fly_zone_polygon->lng, no_fly_zone_polygon->zone_type, no_fly_zone_polygon->alt_max);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON, (const char *)no_fly_zone_polygon, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
#endif
}

#if MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_no_fly_zone_polygon_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, uint8_t id, uint16_t total_point, uint16_t curr_index, double lat, double lng, uint8_t zone_type, uint16_t alt_max)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_double(buf, 8, lat);
    _mav_put_double(buf, 16, lng);
    _mav_put_uint16_t(buf, 24, total_point);
    _mav_put_uint16_t(buf, 26, curr_index);
    _mav_put_uint16_t(buf, 28, alt_max);
    _mav_put_uint8_t(buf, 30, id);
    _mav_put_uint8_t(buf, 31, zone_type);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON, buf, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
#else
    mavlink_no_fly_zone_polygon_t *packet = (mavlink_no_fly_zone_polygon_t *)msgbuf;
    packet->time_usec = time_usec;
    packet->lat = lat;
    packet->lng = lng;
    packet->total_point = total_point;
    packet->curr_index = curr_index;
    packet->alt_max = alt_max;
    packet->id = id;
    packet->zone_type = zone_type;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON, (const char *)packet, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_MIN_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_CRC);
#endif
}
#endif

#endif

// MESSAGE NO_FLY_ZONE_POLYGON UNPACKING


/**
 * @brief Get field time_usec from no_fly_zone_polygon message
 *
 * @return [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude of the number.
 */
static inline uint64_t mavlink_msg_no_fly_zone_polygon_get_time_usec(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  0);
}

/**
 * @brief Get field id from no_fly_zone_polygon message
 *
 * @return   No. fly zone circle id.
 */
static inline uint8_t mavlink_msg_no_fly_zone_polygon_get_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  30);
}

/**
 * @brief Get field total_point from no_fly_zone_polygon message
 *
 * @return  Which type of area circle/polygon
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_get_total_point(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  24);
}

/**
 * @brief Get field curr_index from no_fly_zone_polygon message
 *
 * @return  current index of current position in polygon
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_get_curr_index(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  26);
}

/**
 * @brief Get field lat from no_fly_zone_polygon message
 *
 * @return  Latitude of centre of circle or Latitude array of polygon.
 */
static inline double mavlink_msg_no_fly_zone_polygon_get_lat(const mavlink_message_t* msg)
{
    return _MAV_RETURN_double(msg,  8);
}

/**
 * @brief Get field lng from no_fly_zone_polygon message
 *
 * @return  Longitude of centre of circle or longitude array of polygon.
 */
static inline double mavlink_msg_no_fly_zone_polygon_get_lng(const mavlink_message_t* msg)
{
    return _MAV_RETURN_double(msg,  16);
}

/**
 * @brief Get field zone_type from no_fly_zone_polygon message
 *
 * @return  Which zone? yellow/red
 */
static inline uint8_t mavlink_msg_no_fly_zone_polygon_get_zone_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  31);
}

/**
 * @brief Get field alt_max from no_fly_zone_polygon message
 *
 * @return  Maximum altitude flying allowed
 */
static inline uint16_t mavlink_msg_no_fly_zone_polygon_get_alt_max(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  28);
}

/**
 * @brief Decode a no_fly_zone_polygon message into a struct
 *
 * @param msg The message to decode
 * @param no_fly_zone_polygon C-struct to decode the message contents into
 */
static inline void mavlink_msg_no_fly_zone_polygon_decode(const mavlink_message_t* msg, mavlink_no_fly_zone_polygon_t* no_fly_zone_polygon)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    no_fly_zone_polygon->time_usec = mavlink_msg_no_fly_zone_polygon_get_time_usec(msg);
    no_fly_zone_polygon->lat = mavlink_msg_no_fly_zone_polygon_get_lat(msg);
    no_fly_zone_polygon->lng = mavlink_msg_no_fly_zone_polygon_get_lng(msg);
    no_fly_zone_polygon->total_point = mavlink_msg_no_fly_zone_polygon_get_total_point(msg);
    no_fly_zone_polygon->curr_index = mavlink_msg_no_fly_zone_polygon_get_curr_index(msg);
    no_fly_zone_polygon->alt_max = mavlink_msg_no_fly_zone_polygon_get_alt_max(msg);
    no_fly_zone_polygon->id = mavlink_msg_no_fly_zone_polygon_get_id(msg);
    no_fly_zone_polygon->zone_type = mavlink_msg_no_fly_zone_polygon_get_zone_type(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN? msg->len : MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN;
        memset(no_fly_zone_polygon, 0, MAVLINK_MSG_ID_NO_FLY_ZONE_POLYGON_LEN);
    memcpy(no_fly_zone_polygon, _MAV_PAYLOAD(msg), len);
#endif
}
