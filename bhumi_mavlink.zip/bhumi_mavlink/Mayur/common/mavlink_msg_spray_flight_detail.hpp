// MESSAGE SPRAY_FLIGHT_DETAIL support class

#pragma once

namespace mavlink {
namespace common {
namespace msg {

/**
 * @brief SPRAY_FLIGHT_DETAIL message
 *
 * The Spray related Calculation such as flight time and spray area etc.
 */
struct SPRAY_FLIGHT_DETAIL : mavlink::Message {
    static constexpr msgid_t MSG_ID = 12921;
    static constexpr size_t LENGTH = 36;
    static constexpr size_t MIN_LENGTH = 36;
    static constexpr uint8_t CRC_EXTRA = 215;
    static constexpr auto NAME = "SPRAY_FLIGHT_DETAIL";


    uint32_t time_boot_ms; /*< [ms] Timestamp (time since system boot). */
    uint32_t flight_time; /*< [ms] Total Flight Time */
    uint32_t spray_time; /*< [ms] Total Spray Time */
    float spray_dist; /*< [m] Total Spray Distance */
    float flight_dist; /*< [m] Total Flight Distance */
    float spray_area_sqm; /*< [sqm] Total Flight Spray Area Covered in sqm  */
    float spray_area_acre; /*< [Acre] Total Flight Spray Area Covered in Acre */
    float flight_alt; /*< [m] Vehicle Altitude While Flight */
    float consumed_liquid; /*< [m] consumed liquid while flight */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  time_boot_ms: " << time_boot_ms << std::endl;
        ss << "  flight_time: " << flight_time << std::endl;
        ss << "  spray_time: " << spray_time << std::endl;
        ss << "  spray_dist: " << spray_dist << std::endl;
        ss << "  flight_dist: " << flight_dist << std::endl;
        ss << "  spray_area_sqm: " << spray_area_sqm << std::endl;
        ss << "  spray_area_acre: " << spray_area_acre << std::endl;
        ss << "  flight_alt: " << flight_alt << std::endl;
        ss << "  consumed_liquid: " << consumed_liquid << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << time_boot_ms;                  // offset: 0
        map << flight_time;                   // offset: 4
        map << spray_time;                    // offset: 8
        map << spray_dist;                    // offset: 12
        map << flight_dist;                   // offset: 16
        map << spray_area_sqm;                // offset: 20
        map << spray_area_acre;               // offset: 24
        map << flight_alt;                    // offset: 28
        map << consumed_liquid;               // offset: 32
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> time_boot_ms;                  // offset: 0
        map >> flight_time;                   // offset: 4
        map >> spray_time;                    // offset: 8
        map >> spray_dist;                    // offset: 12
        map >> flight_dist;                   // offset: 16
        map >> spray_area_sqm;                // offset: 20
        map >> spray_area_acre;               // offset: 24
        map >> flight_alt;                    // offset: 28
        map >> consumed_liquid;               // offset: 32
    }
};

} // namespace msg
} // namespace common
} // namespace mavlink
