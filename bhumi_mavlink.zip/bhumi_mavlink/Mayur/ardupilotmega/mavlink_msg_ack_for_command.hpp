// MESSAGE ACK_FOR_COMMAND support class

#pragma once

namespace mavlink {
namespace ardupilotmega {
namespace msg {

/**
 * @brief ACK_FOR_COMMAND message
 *
 * ACK for above command .
 */
struct ACK_FOR_COMMAND : mavlink::Message {
    static constexpr msgid_t MSG_ID = 229;
    static constexpr size_t LENGTH = 3;
    static constexpr size_t MIN_LENGTH = 3;
    static constexpr uint8_t CRC_EXTRA = 204;
    static constexpr auto NAME = "ACK_FOR_COMMAND";


    uint8_t command; /*<  command which ask for ack */
    uint8_t command_type; /*<  command type which ask for ask */
    uint8_t ack; /*<  is ack sucess or failed */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  command: " << +command << std::endl;
        ss << "  command_type: " << +command_type << std::endl;
        ss << "  ack: " << +ack << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << command;                       // offset: 0
        map << command_type;                  // offset: 1
        map << ack;                           // offset: 2
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> command;                       // offset: 0
        map >> command_type;                  // offset: 1
        map >> ack;                           // offset: 2
    }
};

} // namespace msg
} // namespace ardupilotmega
} // namespace mavlink
