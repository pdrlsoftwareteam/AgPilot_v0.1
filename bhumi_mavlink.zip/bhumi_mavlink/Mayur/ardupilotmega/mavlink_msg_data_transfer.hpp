// MESSAGE DATA_TRANSFER support class

#pragma once

namespace mavlink {
namespace ardupilotmega {
namespace msg {

/**
 * @brief DATA_TRANSFER message
 *
 * Used To transfer RSA key pair information PDRL.
 */
struct DATA_TRANSFER : mavlink::Message {
    static constexpr msgid_t MSG_ID = 227;
    static constexpr size_t LENGTH = 254;
    static constexpr size_t MIN_LENGTH = 254;
    static constexpr uint8_t CRC_EXTRA = 0;
    static constexpr auto NAME = "DATA_TRANSFER";


    uint8_t data_type; /*<  data type private = 0 , public = 1 PDRL. */
    uint8_t buffer_index; /*<  Current buffer index PDRL. */
    std::array<uint8_t, 250> data_buffer; /*<  Send key buffer in chunk of 250 bytes at time PDRL. */
    uint16_t valid_data_len; /*<  Number of valid data bytes in data_buffer PDRL. */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  data_type: " << +data_type << std::endl;
        ss << "  buffer_index: " << +buffer_index << std::endl;
        ss << "  data_buffer: [" << to_string(data_buffer) << "]" << std::endl;
        ss << "  valid_data_len: " << valid_data_len << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << valid_data_len;                // offset: 0
        map << data_type;                     // offset: 2
        map << buffer_index;                  // offset: 3
        map << data_buffer;                   // offset: 4
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> valid_data_len;                // offset: 0
        map >> data_type;                     // offset: 2
        map >> buffer_index;                  // offset: 3
        map >> data_buffer;                   // offset: 4
    }
};

} // namespace msg
} // namespace ardupilotmega
} // namespace mavlink
