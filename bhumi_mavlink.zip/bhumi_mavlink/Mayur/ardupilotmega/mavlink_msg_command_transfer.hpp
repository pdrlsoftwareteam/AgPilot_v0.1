// MESSAGE COMMAND_TRANSFER support class

#pragma once

namespace mavlink {
namespace ardupilotmega {
namespace msg {

/**
 * @brief COMMAND_TRANSFER message
 *
 * Used To transfer Command Information PDRL.
 */
struct COMMAND_TRANSFER : mavlink::Message {
    static constexpr msgid_t MSG_ID = 228;
    static constexpr size_t LENGTH = 127;
    static constexpr size_t MIN_LENGTH = 127;
    static constexpr uint8_t CRC_EXTRA = 206;
    static constexpr auto NAME = "COMMAND_TRANSFER";


    uint8_t command; /*<  command from GCS to FC or FC to GCS PDRL. */
    uint8_t command_type; /*<  0. Requst , 1. Response PDRL. */
    uint8_t is_ack_required; /*<  0. No Ack required , 1. Ack required PDRL. */
    uint64_t data_len; /*<  Data length 0 - 30. */
    uint64_t item_count; /*<  Item Count  0 - 255. */
    uint64_t item_offset; /*<  Item Offset 0 - 65535. */
    std::array<uint8_t, 100> command_buff; /*<  fixed length command buffer PDRL. */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  command: " << +command << std::endl;
        ss << "  command_type: " << +command_type << std::endl;
        ss << "  is_ack_required: " << +is_ack_required << std::endl;
        ss << "  data_len: " << data_len << std::endl;
        ss << "  item_count: " << item_count << std::endl;
        ss << "  item_offset: " << item_offset << std::endl;
        ss << "  command_buff: [" << to_string(command_buff) << "]" << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << data_len;                      // offset: 0
        map << item_count;                    // offset: 8
        map << item_offset;                   // offset: 16
        map << command;                       // offset: 24
        map << command_type;                  // offset: 25
        map << is_ack_required;               // offset: 26
        map << command_buff;                  // offset: 27
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> data_len;                      // offset: 0
        map >> item_count;                    // offset: 8
        map >> item_offset;                   // offset: 16
        map >> command;                       // offset: 24
        map >> command_type;                  // offset: 25
        map >> is_ack_required;               // offset: 26
        map >> command_buff;                  // offset: 27
    }
};

} // namespace msg
} // namespace ardupilotmega
} // namespace mavlink
