#pragma once
// MESSAGE CAN_BMS_STATUS PACKING

#define MAVLINK_MSG_ID_CAN_BMS_STATUS 371


typedef struct __mavlink_can_bms_status_t {
 uint32_t capacity; /*< [mAh] Nominal capacity, divide by 1000*/
 uint32_t remaining_capacity; /*< [mAh] Remaining capacity, divide by 1000*/
 float batt_volt; /*< [V] Battery voltage, divide by 1000*/
 float batt_curr; /*< [A] Battery current, divide by 1000 then subtract 1500*/
 float batt_chr_volt; /*< [V] Charger voltage, divide by 100*/
 float max_cell_volt; /*< [V] Max cell voltage, divide by 1000*/
 float min_cell_volt; /*< [V] Min cell voltage, divide by 1000*/
 uint32_t fault_flags; /*<  Fault flags*/
 uint32_t warning_flags; /*<  Warning flags*/
 uint16_t firmware_info; /*<  Firmware version divided by 100*/
 uint16_t soc; /*< [%] State of Charge, divide by 10*/
 uint16_t soh; /*< [%] State of Health, divide by 10*/
 uint16_t balancing_status_cc1; /*<  Balancing status CC1*/
 uint16_t balancing_status_cc2; /*<  Balancing status CC2*/
 uint16_t balancing_status_cc3; /*<  Balancing status CC3*/
 uint16_t balancing_status_cc4; /*<  Balancing status CC4*/
 uint16_t cell_voltages[14]; /*< [mV] Cell voltages, raw. 0 = unused.*/
 uint8_t id; /*<  Battery ID*/
 char uid_str[33]; /*<  Unique ID string (ASCII, null-terminated)*/
 uint8_t max_cell_volt_cell_loc; /*<  Location of max voltage cell*/
 uint8_t max_cell_volt_cell_ctr; /*<  Count of cells with max voltage*/
 uint8_t min_cell_volt_cell_loc; /*<  Location of min voltage cell*/
 uint8_t min_cell_volt_cell_ctr; /*<  Count of cells with min voltage*/
 int8_t max_temp; /*< [degC] Max temperature (offset -128)*/
 uint8_t max_temp_ntc_loc_cell; /*<  NTC cell for max temp*/
 uint8_t max_temp_ntc_loc_ctr; /*<  NTC controller for max temp*/
 int8_t min_temp; /*< [degC] Min temperature (offset -128)*/
 uint8_t min_temp_ntc_loc_cell; /*<  NTC cell for min temp*/
 uint8_t min_temp_ntc_loc_ctr; /*<  NTC controller for min temp*/
 uint8_t bms_state; /*<  BMS state*/
 uint8_t relay_precharge; /*<  Relay precharge status (0/1)*/
 uint8_t relay_charge; /*<  Relay charge status (0/1)*/
 uint8_t relay_negative; /*<  Relay negative status (0/1)*/
 uint8_t relay_positive; /*<  Relay positive status (0/1)*/
 int8_t temperatures_ntc[7]; /*< [degC] Temperatures from NTC sensors, offset -128*/
 uint8_t cell_count_series; /*<  Number of cells in series*/
} mavlink_can_bms_status_t;

#define MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN 135
#define MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN 135
#define MAVLINK_MSG_ID_371_LEN 135
#define MAVLINK_MSG_ID_371_MIN_LEN 135

#define MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC 145
#define MAVLINK_MSG_ID_371_CRC 145

#define MAVLINK_MSG_CAN_BMS_STATUS_FIELD_CELL_VOLTAGES_LEN 14
#define MAVLINK_MSG_CAN_BMS_STATUS_FIELD_UID_STR_LEN 33
#define MAVLINK_MSG_CAN_BMS_STATUS_FIELD_TEMPERATURES_NTC_LEN 7

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_CAN_BMS_STATUS { \
    371, \
    "CAN_BMS_STATUS", \
    36, \
    {  { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 78, offsetof(mavlink_can_bms_status_t, id) }, \
         { "firmware_info", NULL, MAVLINK_TYPE_UINT16_T, 0, 36, offsetof(mavlink_can_bms_status_t, firmware_info) }, \
         { "uid_str", NULL, MAVLINK_TYPE_CHAR, 33, 79, offsetof(mavlink_can_bms_status_t, uid_str) }, \
         { "soc", NULL, MAVLINK_TYPE_UINT16_T, 0, 38, offsetof(mavlink_can_bms_status_t, soc) }, \
         { "soh", NULL, MAVLINK_TYPE_UINT16_T, 0, 40, offsetof(mavlink_can_bms_status_t, soh) }, \
         { "capacity", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_can_bms_status_t, capacity) }, \
         { "remaining_capacity", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_can_bms_status_t, remaining_capacity) }, \
         { "batt_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_can_bms_status_t, batt_volt) }, \
         { "batt_curr", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_can_bms_status_t, batt_curr) }, \
         { "batt_chr_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_can_bms_status_t, batt_chr_volt) }, \
         { "max_cell_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_can_bms_status_t, max_cell_volt) }, \
         { "max_cell_volt_cell_loc", NULL, MAVLINK_TYPE_UINT8_T, 0, 112, offsetof(mavlink_can_bms_status_t, max_cell_volt_cell_loc) }, \
         { "max_cell_volt_cell_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 113, offsetof(mavlink_can_bms_status_t, max_cell_volt_cell_ctr) }, \
         { "min_cell_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_can_bms_status_t, min_cell_volt) }, \
         { "min_cell_volt_cell_loc", NULL, MAVLINK_TYPE_UINT8_T, 0, 114, offsetof(mavlink_can_bms_status_t, min_cell_volt_cell_loc) }, \
         { "min_cell_volt_cell_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 115, offsetof(mavlink_can_bms_status_t, min_cell_volt_cell_ctr) }, \
         { "max_temp", NULL, MAVLINK_TYPE_INT8_T, 0, 116, offsetof(mavlink_can_bms_status_t, max_temp) }, \
         { "max_temp_ntc_loc_cell", NULL, MAVLINK_TYPE_UINT8_T, 0, 117, offsetof(mavlink_can_bms_status_t, max_temp_ntc_loc_cell) }, \
         { "max_temp_ntc_loc_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 118, offsetof(mavlink_can_bms_status_t, max_temp_ntc_loc_ctr) }, \
         { "min_temp", NULL, MAVLINK_TYPE_INT8_T, 0, 119, offsetof(mavlink_can_bms_status_t, min_temp) }, \
         { "min_temp_ntc_loc_cell", NULL, MAVLINK_TYPE_UINT8_T, 0, 120, offsetof(mavlink_can_bms_status_t, min_temp_ntc_loc_cell) }, \
         { "min_temp_ntc_loc_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 121, offsetof(mavlink_can_bms_status_t, min_temp_ntc_loc_ctr) }, \
         { "bms_state", NULL, MAVLINK_TYPE_UINT8_T, 0, 122, offsetof(mavlink_can_bms_status_t, bms_state) }, \
         { "relay_precharge", NULL, MAVLINK_TYPE_UINT8_T, 0, 123, offsetof(mavlink_can_bms_status_t, relay_precharge) }, \
         { "relay_charge", NULL, MAVLINK_TYPE_UINT8_T, 0, 124, offsetof(mavlink_can_bms_status_t, relay_charge) }, \
         { "relay_negative", NULL, MAVLINK_TYPE_UINT8_T, 0, 125, offsetof(mavlink_can_bms_status_t, relay_negative) }, \
         { "relay_positive", NULL, MAVLINK_TYPE_UINT8_T, 0, 126, offsetof(mavlink_can_bms_status_t, relay_positive) }, \
         { "balancing_status_cc1", NULL, MAVLINK_TYPE_UINT16_T, 0, 42, offsetof(mavlink_can_bms_status_t, balancing_status_cc1) }, \
         { "balancing_status_cc2", NULL, MAVLINK_TYPE_UINT16_T, 0, 44, offsetof(mavlink_can_bms_status_t, balancing_status_cc2) }, \
         { "balancing_status_cc3", NULL, MAVLINK_TYPE_UINT16_T, 0, 46, offsetof(mavlink_can_bms_status_t, balancing_status_cc3) }, \
         { "balancing_status_cc4", NULL, MAVLINK_TYPE_UINT16_T, 0, 48, offsetof(mavlink_can_bms_status_t, balancing_status_cc4) }, \
         { "fault_flags", NULL, MAVLINK_TYPE_UINT32_T, 0, 28, offsetof(mavlink_can_bms_status_t, fault_flags) }, \
         { "warning_flags", NULL, MAVLINK_TYPE_UINT32_T, 0, 32, offsetof(mavlink_can_bms_status_t, warning_flags) }, \
         { "temperatures_ntc", NULL, MAVLINK_TYPE_INT8_T, 7, 127, offsetof(mavlink_can_bms_status_t, temperatures_ntc) }, \
         { "cell_voltages", NULL, MAVLINK_TYPE_UINT16_T, 14, 50, offsetof(mavlink_can_bms_status_t, cell_voltages) }, \
         { "cell_count_series", NULL, MAVLINK_TYPE_UINT8_T, 0, 134, offsetof(mavlink_can_bms_status_t, cell_count_series) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_CAN_BMS_STATUS { \
    "CAN_BMS_STATUS", \
    36, \
    {  { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 78, offsetof(mavlink_can_bms_status_t, id) }, \
         { "firmware_info", NULL, MAVLINK_TYPE_UINT16_T, 0, 36, offsetof(mavlink_can_bms_status_t, firmware_info) }, \
         { "uid_str", NULL, MAVLINK_TYPE_CHAR, 33, 79, offsetof(mavlink_can_bms_status_t, uid_str) }, \
         { "soc", NULL, MAVLINK_TYPE_UINT16_T, 0, 38, offsetof(mavlink_can_bms_status_t, soc) }, \
         { "soh", NULL, MAVLINK_TYPE_UINT16_T, 0, 40, offsetof(mavlink_can_bms_status_t, soh) }, \
         { "capacity", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_can_bms_status_t, capacity) }, \
         { "remaining_capacity", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_can_bms_status_t, remaining_capacity) }, \
         { "batt_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_can_bms_status_t, batt_volt) }, \
         { "batt_curr", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_can_bms_status_t, batt_curr) }, \
         { "batt_chr_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_can_bms_status_t, batt_chr_volt) }, \
         { "max_cell_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_can_bms_status_t, max_cell_volt) }, \
         { "max_cell_volt_cell_loc", NULL, MAVLINK_TYPE_UINT8_T, 0, 112, offsetof(mavlink_can_bms_status_t, max_cell_volt_cell_loc) }, \
         { "max_cell_volt_cell_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 113, offsetof(mavlink_can_bms_status_t, max_cell_volt_cell_ctr) }, \
         { "min_cell_volt", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_can_bms_status_t, min_cell_volt) }, \
         { "min_cell_volt_cell_loc", NULL, MAVLINK_TYPE_UINT8_T, 0, 114, offsetof(mavlink_can_bms_status_t, min_cell_volt_cell_loc) }, \
         { "min_cell_volt_cell_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 115, offsetof(mavlink_can_bms_status_t, min_cell_volt_cell_ctr) }, \
         { "max_temp", NULL, MAVLINK_TYPE_INT8_T, 0, 116, offsetof(mavlink_can_bms_status_t, max_temp) }, \
         { "max_temp_ntc_loc_cell", NULL, MAVLINK_TYPE_UINT8_T, 0, 117, offsetof(mavlink_can_bms_status_t, max_temp_ntc_loc_cell) }, \
         { "max_temp_ntc_loc_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 118, offsetof(mavlink_can_bms_status_t, max_temp_ntc_loc_ctr) }, \
         { "min_temp", NULL, MAVLINK_TYPE_INT8_T, 0, 119, offsetof(mavlink_can_bms_status_t, min_temp) }, \
         { "min_temp_ntc_loc_cell", NULL, MAVLINK_TYPE_UINT8_T, 0, 120, offsetof(mavlink_can_bms_status_t, min_temp_ntc_loc_cell) }, \
         { "min_temp_ntc_loc_ctr", NULL, MAVLINK_TYPE_UINT8_T, 0, 121, offsetof(mavlink_can_bms_status_t, min_temp_ntc_loc_ctr) }, \
         { "bms_state", NULL, MAVLINK_TYPE_UINT8_T, 0, 122, offsetof(mavlink_can_bms_status_t, bms_state) }, \
         { "relay_precharge", NULL, MAVLINK_TYPE_UINT8_T, 0, 123, offsetof(mavlink_can_bms_status_t, relay_precharge) }, \
         { "relay_charge", NULL, MAVLINK_TYPE_UINT8_T, 0, 124, offsetof(mavlink_can_bms_status_t, relay_charge) }, \
         { "relay_negative", NULL, MAVLINK_TYPE_UINT8_T, 0, 125, offsetof(mavlink_can_bms_status_t, relay_negative) }, \
         { "relay_positive", NULL, MAVLINK_TYPE_UINT8_T, 0, 126, offsetof(mavlink_can_bms_status_t, relay_positive) }, \
         { "balancing_status_cc1", NULL, MAVLINK_TYPE_UINT16_T, 0, 42, offsetof(mavlink_can_bms_status_t, balancing_status_cc1) }, \
         { "balancing_status_cc2", NULL, MAVLINK_TYPE_UINT16_T, 0, 44, offsetof(mavlink_can_bms_status_t, balancing_status_cc2) }, \
         { "balancing_status_cc3", NULL, MAVLINK_TYPE_UINT16_T, 0, 46, offsetof(mavlink_can_bms_status_t, balancing_status_cc3) }, \
         { "balancing_status_cc4", NULL, MAVLINK_TYPE_UINT16_T, 0, 48, offsetof(mavlink_can_bms_status_t, balancing_status_cc4) }, \
         { "fault_flags", NULL, MAVLINK_TYPE_UINT32_T, 0, 28, offsetof(mavlink_can_bms_status_t, fault_flags) }, \
         { "warning_flags", NULL, MAVLINK_TYPE_UINT32_T, 0, 32, offsetof(mavlink_can_bms_status_t, warning_flags) }, \
         { "temperatures_ntc", NULL, MAVLINK_TYPE_INT8_T, 7, 127, offsetof(mavlink_can_bms_status_t, temperatures_ntc) }, \
         { "cell_voltages", NULL, MAVLINK_TYPE_UINT16_T, 14, 50, offsetof(mavlink_can_bms_status_t, cell_voltages) }, \
         { "cell_count_series", NULL, MAVLINK_TYPE_UINT8_T, 0, 134, offsetof(mavlink_can_bms_status_t, cell_count_series) }, \
         } \
}
#endif

/**
 * @brief Pack a can_bms_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param id  Battery ID
 * @param firmware_info  Firmware version divided by 100
 * @param uid_str  Unique ID string (ASCII, null-terminated)
 * @param soc [%] State of Charge, divide by 10
 * @param soh [%] State of Health, divide by 10
 * @param capacity [mAh] Nominal capacity, divide by 1000
 * @param remaining_capacity [mAh] Remaining capacity, divide by 1000
 * @param batt_volt [V] Battery voltage, divide by 1000
 * @param batt_curr [A] Battery current, divide by 1000 then subtract 1500
 * @param batt_chr_volt [V] Charger voltage, divide by 100
 * @param max_cell_volt [V] Max cell voltage, divide by 1000
 * @param max_cell_volt_cell_loc  Location of max voltage cell
 * @param max_cell_volt_cell_ctr  Count of cells with max voltage
 * @param min_cell_volt [V] Min cell voltage, divide by 1000
 * @param min_cell_volt_cell_loc  Location of min voltage cell
 * @param min_cell_volt_cell_ctr  Count of cells with min voltage
 * @param max_temp [degC] Max temperature (offset -128)
 * @param max_temp_ntc_loc_cell  NTC cell for max temp
 * @param max_temp_ntc_loc_ctr  NTC controller for max temp
 * @param min_temp [degC] Min temperature (offset -128)
 * @param min_temp_ntc_loc_cell  NTC cell for min temp
 * @param min_temp_ntc_loc_ctr  NTC controller for min temp
 * @param bms_state  BMS state
 * @param relay_precharge  Relay precharge status (0/1)
 * @param relay_charge  Relay charge status (0/1)
 * @param relay_negative  Relay negative status (0/1)
 * @param relay_positive  Relay positive status (0/1)
 * @param balancing_status_cc1  Balancing status CC1
 * @param balancing_status_cc2  Balancing status CC2
 * @param balancing_status_cc3  Balancing status CC3
 * @param balancing_status_cc4  Balancing status CC4
 * @param fault_flags  Fault flags
 * @param warning_flags  Warning flags
 * @param temperatures_ntc [degC] Temperatures from NTC sensors, offset -128
 * @param cell_voltages [mV] Cell voltages, raw. 0 = unused.
 * @param cell_count_series  Number of cells in series
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_can_bms_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t id, uint16_t firmware_info, const char *uid_str, uint16_t soc, uint16_t soh, uint32_t capacity, uint32_t remaining_capacity, float batt_volt, float batt_curr, float batt_chr_volt, float max_cell_volt, uint8_t max_cell_volt_cell_loc, uint8_t max_cell_volt_cell_ctr, float min_cell_volt, uint8_t min_cell_volt_cell_loc, uint8_t min_cell_volt_cell_ctr, int8_t max_temp, uint8_t max_temp_ntc_loc_cell, uint8_t max_temp_ntc_loc_ctr, int8_t min_temp, uint8_t min_temp_ntc_loc_cell, uint8_t min_temp_ntc_loc_ctr, uint8_t bms_state, uint8_t relay_precharge, uint8_t relay_charge, uint8_t relay_negative, uint8_t relay_positive, uint16_t balancing_status_cc1, uint16_t balancing_status_cc2, uint16_t balancing_status_cc3, uint16_t balancing_status_cc4, uint32_t fault_flags, uint32_t warning_flags, const int8_t *temperatures_ntc, const uint16_t *cell_voltages, uint8_t cell_count_series)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, capacity);
    _mav_put_uint32_t(buf, 4, remaining_capacity);
    _mav_put_float(buf, 8, batt_volt);
    _mav_put_float(buf, 12, batt_curr);
    _mav_put_float(buf, 16, batt_chr_volt);
    _mav_put_float(buf, 20, max_cell_volt);
    _mav_put_float(buf, 24, min_cell_volt);
    _mav_put_uint32_t(buf, 28, fault_flags);
    _mav_put_uint32_t(buf, 32, warning_flags);
    _mav_put_uint16_t(buf, 36, firmware_info);
    _mav_put_uint16_t(buf, 38, soc);
    _mav_put_uint16_t(buf, 40, soh);
    _mav_put_uint16_t(buf, 42, balancing_status_cc1);
    _mav_put_uint16_t(buf, 44, balancing_status_cc2);
    _mav_put_uint16_t(buf, 46, balancing_status_cc3);
    _mav_put_uint16_t(buf, 48, balancing_status_cc4);
    _mav_put_uint8_t(buf, 78, id);
    _mav_put_uint8_t(buf, 112, max_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 113, max_cell_volt_cell_ctr);
    _mav_put_uint8_t(buf, 114, min_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 115, min_cell_volt_cell_ctr);
    _mav_put_int8_t(buf, 116, max_temp);
    _mav_put_uint8_t(buf, 117, max_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 118, max_temp_ntc_loc_ctr);
    _mav_put_int8_t(buf, 119, min_temp);
    _mav_put_uint8_t(buf, 120, min_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 121, min_temp_ntc_loc_ctr);
    _mav_put_uint8_t(buf, 122, bms_state);
    _mav_put_uint8_t(buf, 123, relay_precharge);
    _mav_put_uint8_t(buf, 124, relay_charge);
    _mav_put_uint8_t(buf, 125, relay_negative);
    _mav_put_uint8_t(buf, 126, relay_positive);
    _mav_put_uint8_t(buf, 134, cell_count_series);
    _mav_put_uint16_t_array(buf, 50, cell_voltages, 14);
    _mav_put_char_array(buf, 79, uid_str, 33);
    _mav_put_int8_t_array(buf, 127, temperatures_ntc, 7);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN);
#else
    mavlink_can_bms_status_t packet;
    packet.capacity = capacity;
    packet.remaining_capacity = remaining_capacity;
    packet.batt_volt = batt_volt;
    packet.batt_curr = batt_curr;
    packet.batt_chr_volt = batt_chr_volt;
    packet.max_cell_volt = max_cell_volt;
    packet.min_cell_volt = min_cell_volt;
    packet.fault_flags = fault_flags;
    packet.warning_flags = warning_flags;
    packet.firmware_info = firmware_info;
    packet.soc = soc;
    packet.soh = soh;
    packet.balancing_status_cc1 = balancing_status_cc1;
    packet.balancing_status_cc2 = balancing_status_cc2;
    packet.balancing_status_cc3 = balancing_status_cc3;
    packet.balancing_status_cc4 = balancing_status_cc4;
    packet.id = id;
    packet.max_cell_volt_cell_loc = max_cell_volt_cell_loc;
    packet.max_cell_volt_cell_ctr = max_cell_volt_cell_ctr;
    packet.min_cell_volt_cell_loc = min_cell_volt_cell_loc;
    packet.min_cell_volt_cell_ctr = min_cell_volt_cell_ctr;
    packet.max_temp = max_temp;
    packet.max_temp_ntc_loc_cell = max_temp_ntc_loc_cell;
    packet.max_temp_ntc_loc_ctr = max_temp_ntc_loc_ctr;
    packet.min_temp = min_temp;
    packet.min_temp_ntc_loc_cell = min_temp_ntc_loc_cell;
    packet.min_temp_ntc_loc_ctr = min_temp_ntc_loc_ctr;
    packet.bms_state = bms_state;
    packet.relay_precharge = relay_precharge;
    packet.relay_charge = relay_charge;
    packet.relay_negative = relay_negative;
    packet.relay_positive = relay_positive;
    packet.cell_count_series = cell_count_series;
    mav_array_memcpy(packet.cell_voltages, cell_voltages, sizeof(uint16_t)*14);
    mav_array_memcpy(packet.uid_str, uid_str, sizeof(char)*33);
    mav_array_memcpy(packet.temperatures_ntc, temperatures_ntc, sizeof(int8_t)*7);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CAN_BMS_STATUS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
}

/**
 * @brief Pack a can_bms_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param id  Battery ID
 * @param firmware_info  Firmware version divided by 100
 * @param uid_str  Unique ID string (ASCII, null-terminated)
 * @param soc [%] State of Charge, divide by 10
 * @param soh [%] State of Health, divide by 10
 * @param capacity [mAh] Nominal capacity, divide by 1000
 * @param remaining_capacity [mAh] Remaining capacity, divide by 1000
 * @param batt_volt [V] Battery voltage, divide by 1000
 * @param batt_curr [A] Battery current, divide by 1000 then subtract 1500
 * @param batt_chr_volt [V] Charger voltage, divide by 100
 * @param max_cell_volt [V] Max cell voltage, divide by 1000
 * @param max_cell_volt_cell_loc  Location of max voltage cell
 * @param max_cell_volt_cell_ctr  Count of cells with max voltage
 * @param min_cell_volt [V] Min cell voltage, divide by 1000
 * @param min_cell_volt_cell_loc  Location of min voltage cell
 * @param min_cell_volt_cell_ctr  Count of cells with min voltage
 * @param max_temp [degC] Max temperature (offset -128)
 * @param max_temp_ntc_loc_cell  NTC cell for max temp
 * @param max_temp_ntc_loc_ctr  NTC controller for max temp
 * @param min_temp [degC] Min temperature (offset -128)
 * @param min_temp_ntc_loc_cell  NTC cell for min temp
 * @param min_temp_ntc_loc_ctr  NTC controller for min temp
 * @param bms_state  BMS state
 * @param relay_precharge  Relay precharge status (0/1)
 * @param relay_charge  Relay charge status (0/1)
 * @param relay_negative  Relay negative status (0/1)
 * @param relay_positive  Relay positive status (0/1)
 * @param balancing_status_cc1  Balancing status CC1
 * @param balancing_status_cc2  Balancing status CC2
 * @param balancing_status_cc3  Balancing status CC3
 * @param balancing_status_cc4  Balancing status CC4
 * @param fault_flags  Fault flags
 * @param warning_flags  Warning flags
 * @param temperatures_ntc [degC] Temperatures from NTC sensors, offset -128
 * @param cell_voltages [mV] Cell voltages, raw. 0 = unused.
 * @param cell_count_series  Number of cells in series
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_can_bms_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t id,uint16_t firmware_info,const char *uid_str,uint16_t soc,uint16_t soh,uint32_t capacity,uint32_t remaining_capacity,float batt_volt,float batt_curr,float batt_chr_volt,float max_cell_volt,uint8_t max_cell_volt_cell_loc,uint8_t max_cell_volt_cell_ctr,float min_cell_volt,uint8_t min_cell_volt_cell_loc,uint8_t min_cell_volt_cell_ctr,int8_t max_temp,uint8_t max_temp_ntc_loc_cell,uint8_t max_temp_ntc_loc_ctr,int8_t min_temp,uint8_t min_temp_ntc_loc_cell,uint8_t min_temp_ntc_loc_ctr,uint8_t bms_state,uint8_t relay_precharge,uint8_t relay_charge,uint8_t relay_negative,uint8_t relay_positive,uint16_t balancing_status_cc1,uint16_t balancing_status_cc2,uint16_t balancing_status_cc3,uint16_t balancing_status_cc4,uint32_t fault_flags,uint32_t warning_flags,const int8_t *temperatures_ntc,const uint16_t *cell_voltages,uint8_t cell_count_series)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, capacity);
    _mav_put_uint32_t(buf, 4, remaining_capacity);
    _mav_put_float(buf, 8, batt_volt);
    _mav_put_float(buf, 12, batt_curr);
    _mav_put_float(buf, 16, batt_chr_volt);
    _mav_put_float(buf, 20, max_cell_volt);
    _mav_put_float(buf, 24, min_cell_volt);
    _mav_put_uint32_t(buf, 28, fault_flags);
    _mav_put_uint32_t(buf, 32, warning_flags);
    _mav_put_uint16_t(buf, 36, firmware_info);
    _mav_put_uint16_t(buf, 38, soc);
    _mav_put_uint16_t(buf, 40, soh);
    _mav_put_uint16_t(buf, 42, balancing_status_cc1);
    _mav_put_uint16_t(buf, 44, balancing_status_cc2);
    _mav_put_uint16_t(buf, 46, balancing_status_cc3);
    _mav_put_uint16_t(buf, 48, balancing_status_cc4);
    _mav_put_uint8_t(buf, 78, id);
    _mav_put_uint8_t(buf, 112, max_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 113, max_cell_volt_cell_ctr);
    _mav_put_uint8_t(buf, 114, min_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 115, min_cell_volt_cell_ctr);
    _mav_put_int8_t(buf, 116, max_temp);
    _mav_put_uint8_t(buf, 117, max_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 118, max_temp_ntc_loc_ctr);
    _mav_put_int8_t(buf, 119, min_temp);
    _mav_put_uint8_t(buf, 120, min_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 121, min_temp_ntc_loc_ctr);
    _mav_put_uint8_t(buf, 122, bms_state);
    _mav_put_uint8_t(buf, 123, relay_precharge);
    _mav_put_uint8_t(buf, 124, relay_charge);
    _mav_put_uint8_t(buf, 125, relay_negative);
    _mav_put_uint8_t(buf, 126, relay_positive);
    _mav_put_uint8_t(buf, 134, cell_count_series);
    _mav_put_uint16_t_array(buf, 50, cell_voltages, 14);
    _mav_put_char_array(buf, 79, uid_str, 33);
    _mav_put_int8_t_array(buf, 127, temperatures_ntc, 7);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN);
#else
    mavlink_can_bms_status_t packet;
    packet.capacity = capacity;
    packet.remaining_capacity = remaining_capacity;
    packet.batt_volt = batt_volt;
    packet.batt_curr = batt_curr;
    packet.batt_chr_volt = batt_chr_volt;
    packet.max_cell_volt = max_cell_volt;
    packet.min_cell_volt = min_cell_volt;
    packet.fault_flags = fault_flags;
    packet.warning_flags = warning_flags;
    packet.firmware_info = firmware_info;
    packet.soc = soc;
    packet.soh = soh;
    packet.balancing_status_cc1 = balancing_status_cc1;
    packet.balancing_status_cc2 = balancing_status_cc2;
    packet.balancing_status_cc3 = balancing_status_cc3;
    packet.balancing_status_cc4 = balancing_status_cc4;
    packet.id = id;
    packet.max_cell_volt_cell_loc = max_cell_volt_cell_loc;
    packet.max_cell_volt_cell_ctr = max_cell_volt_cell_ctr;
    packet.min_cell_volt_cell_loc = min_cell_volt_cell_loc;
    packet.min_cell_volt_cell_ctr = min_cell_volt_cell_ctr;
    packet.max_temp = max_temp;
    packet.max_temp_ntc_loc_cell = max_temp_ntc_loc_cell;
    packet.max_temp_ntc_loc_ctr = max_temp_ntc_loc_ctr;
    packet.min_temp = min_temp;
    packet.min_temp_ntc_loc_cell = min_temp_ntc_loc_cell;
    packet.min_temp_ntc_loc_ctr = min_temp_ntc_loc_ctr;
    packet.bms_state = bms_state;
    packet.relay_precharge = relay_precharge;
    packet.relay_charge = relay_charge;
    packet.relay_negative = relay_negative;
    packet.relay_positive = relay_positive;
    packet.cell_count_series = cell_count_series;
    mav_array_memcpy(packet.cell_voltages, cell_voltages, sizeof(uint16_t)*14);
    mav_array_memcpy(packet.uid_str, uid_str, sizeof(char)*33);
    mav_array_memcpy(packet.temperatures_ntc, temperatures_ntc, sizeof(int8_t)*7);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CAN_BMS_STATUS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
}

/**
 * @brief Encode a can_bms_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param can_bms_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_can_bms_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_can_bms_status_t* can_bms_status)
{
    return mavlink_msg_can_bms_status_pack(system_id, component_id, msg, can_bms_status->id, can_bms_status->firmware_info, can_bms_status->uid_str, can_bms_status->soc, can_bms_status->soh, can_bms_status->capacity, can_bms_status->remaining_capacity, can_bms_status->batt_volt, can_bms_status->batt_curr, can_bms_status->batt_chr_volt, can_bms_status->max_cell_volt, can_bms_status->max_cell_volt_cell_loc, can_bms_status->max_cell_volt_cell_ctr, can_bms_status->min_cell_volt, can_bms_status->min_cell_volt_cell_loc, can_bms_status->min_cell_volt_cell_ctr, can_bms_status->max_temp, can_bms_status->max_temp_ntc_loc_cell, can_bms_status->max_temp_ntc_loc_ctr, can_bms_status->min_temp, can_bms_status->min_temp_ntc_loc_cell, can_bms_status->min_temp_ntc_loc_ctr, can_bms_status->bms_state, can_bms_status->relay_precharge, can_bms_status->relay_charge, can_bms_status->relay_negative, can_bms_status->relay_positive, can_bms_status->balancing_status_cc1, can_bms_status->balancing_status_cc2, can_bms_status->balancing_status_cc3, can_bms_status->balancing_status_cc4, can_bms_status->fault_flags, can_bms_status->warning_flags, can_bms_status->temperatures_ntc, can_bms_status->cell_voltages, can_bms_status->cell_count_series);
}

/**
 * @brief Encode a can_bms_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param can_bms_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_can_bms_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_can_bms_status_t* can_bms_status)
{
    return mavlink_msg_can_bms_status_pack_chan(system_id, component_id, chan, msg, can_bms_status->id, can_bms_status->firmware_info, can_bms_status->uid_str, can_bms_status->soc, can_bms_status->soh, can_bms_status->capacity, can_bms_status->remaining_capacity, can_bms_status->batt_volt, can_bms_status->batt_curr, can_bms_status->batt_chr_volt, can_bms_status->max_cell_volt, can_bms_status->max_cell_volt_cell_loc, can_bms_status->max_cell_volt_cell_ctr, can_bms_status->min_cell_volt, can_bms_status->min_cell_volt_cell_loc, can_bms_status->min_cell_volt_cell_ctr, can_bms_status->max_temp, can_bms_status->max_temp_ntc_loc_cell, can_bms_status->max_temp_ntc_loc_ctr, can_bms_status->min_temp, can_bms_status->min_temp_ntc_loc_cell, can_bms_status->min_temp_ntc_loc_ctr, can_bms_status->bms_state, can_bms_status->relay_precharge, can_bms_status->relay_charge, can_bms_status->relay_negative, can_bms_status->relay_positive, can_bms_status->balancing_status_cc1, can_bms_status->balancing_status_cc2, can_bms_status->balancing_status_cc3, can_bms_status->balancing_status_cc4, can_bms_status->fault_flags, can_bms_status->warning_flags, can_bms_status->temperatures_ntc, can_bms_status->cell_voltages, can_bms_status->cell_count_series);
}

/**
 * @brief Send a can_bms_status message
 * @param chan MAVLink channel to send the message
 *
 * @param id  Battery ID
 * @param firmware_info  Firmware version divided by 100
 * @param uid_str  Unique ID string (ASCII, null-terminated)
 * @param soc [%] State of Charge, divide by 10
 * @param soh [%] State of Health, divide by 10
 * @param capacity [mAh] Nominal capacity, divide by 1000
 * @param remaining_capacity [mAh] Remaining capacity, divide by 1000
 * @param batt_volt [V] Battery voltage, divide by 1000
 * @param batt_curr [A] Battery current, divide by 1000 then subtract 1500
 * @param batt_chr_volt [V] Charger voltage, divide by 100
 * @param max_cell_volt [V] Max cell voltage, divide by 1000
 * @param max_cell_volt_cell_loc  Location of max voltage cell
 * @param max_cell_volt_cell_ctr  Count of cells with max voltage
 * @param min_cell_volt [V] Min cell voltage, divide by 1000
 * @param min_cell_volt_cell_loc  Location of min voltage cell
 * @param min_cell_volt_cell_ctr  Count of cells with min voltage
 * @param max_temp [degC] Max temperature (offset -128)
 * @param max_temp_ntc_loc_cell  NTC cell for max temp
 * @param max_temp_ntc_loc_ctr  NTC controller for max temp
 * @param min_temp [degC] Min temperature (offset -128)
 * @param min_temp_ntc_loc_cell  NTC cell for min temp
 * @param min_temp_ntc_loc_ctr  NTC controller for min temp
 * @param bms_state  BMS state
 * @param relay_precharge  Relay precharge status (0/1)
 * @param relay_charge  Relay charge status (0/1)
 * @param relay_negative  Relay negative status (0/1)
 * @param relay_positive  Relay positive status (0/1)
 * @param balancing_status_cc1  Balancing status CC1
 * @param balancing_status_cc2  Balancing status CC2
 * @param balancing_status_cc3  Balancing status CC3
 * @param balancing_status_cc4  Balancing status CC4
 * @param fault_flags  Fault flags
 * @param warning_flags  Warning flags
 * @param temperatures_ntc [degC] Temperatures from NTC sensors, offset -128
 * @param cell_voltages [mV] Cell voltages, raw. 0 = unused.
 * @param cell_count_series  Number of cells in series
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_can_bms_status_send(mavlink_channel_t chan, uint8_t id, uint16_t firmware_info, const char *uid_str, uint16_t soc, uint16_t soh, uint32_t capacity, uint32_t remaining_capacity, float batt_volt, float batt_curr, float batt_chr_volt, float max_cell_volt, uint8_t max_cell_volt_cell_loc, uint8_t max_cell_volt_cell_ctr, float min_cell_volt, uint8_t min_cell_volt_cell_loc, uint8_t min_cell_volt_cell_ctr, int8_t max_temp, uint8_t max_temp_ntc_loc_cell, uint8_t max_temp_ntc_loc_ctr, int8_t min_temp, uint8_t min_temp_ntc_loc_cell, uint8_t min_temp_ntc_loc_ctr, uint8_t bms_state, uint8_t relay_precharge, uint8_t relay_charge, uint8_t relay_negative, uint8_t relay_positive, uint16_t balancing_status_cc1, uint16_t balancing_status_cc2, uint16_t balancing_status_cc3, uint16_t balancing_status_cc4, uint32_t fault_flags, uint32_t warning_flags, const int8_t *temperatures_ntc, const uint16_t *cell_voltages, uint8_t cell_count_series)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, capacity);
    _mav_put_uint32_t(buf, 4, remaining_capacity);
    _mav_put_float(buf, 8, batt_volt);
    _mav_put_float(buf, 12, batt_curr);
    _mav_put_float(buf, 16, batt_chr_volt);
    _mav_put_float(buf, 20, max_cell_volt);
    _mav_put_float(buf, 24, min_cell_volt);
    _mav_put_uint32_t(buf, 28, fault_flags);
    _mav_put_uint32_t(buf, 32, warning_flags);
    _mav_put_uint16_t(buf, 36, firmware_info);
    _mav_put_uint16_t(buf, 38, soc);
    _mav_put_uint16_t(buf, 40, soh);
    _mav_put_uint16_t(buf, 42, balancing_status_cc1);
    _mav_put_uint16_t(buf, 44, balancing_status_cc2);
    _mav_put_uint16_t(buf, 46, balancing_status_cc3);
    _mav_put_uint16_t(buf, 48, balancing_status_cc4);
    _mav_put_uint8_t(buf, 78, id);
    _mav_put_uint8_t(buf, 112, max_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 113, max_cell_volt_cell_ctr);
    _mav_put_uint8_t(buf, 114, min_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 115, min_cell_volt_cell_ctr);
    _mav_put_int8_t(buf, 116, max_temp);
    _mav_put_uint8_t(buf, 117, max_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 118, max_temp_ntc_loc_ctr);
    _mav_put_int8_t(buf, 119, min_temp);
    _mav_put_uint8_t(buf, 120, min_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 121, min_temp_ntc_loc_ctr);
    _mav_put_uint8_t(buf, 122, bms_state);
    _mav_put_uint8_t(buf, 123, relay_precharge);
    _mav_put_uint8_t(buf, 124, relay_charge);
    _mav_put_uint8_t(buf, 125, relay_negative);
    _mav_put_uint8_t(buf, 126, relay_positive);
    _mav_put_uint8_t(buf, 134, cell_count_series);
    _mav_put_uint16_t_array(buf, 50, cell_voltages, 14);
    _mav_put_char_array(buf, 79, uid_str, 33);
    _mav_put_int8_t_array(buf, 127, temperatures_ntc, 7);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CAN_BMS_STATUS, buf, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
#else
    mavlink_can_bms_status_t packet;
    packet.capacity = capacity;
    packet.remaining_capacity = remaining_capacity;
    packet.batt_volt = batt_volt;
    packet.batt_curr = batt_curr;
    packet.batt_chr_volt = batt_chr_volt;
    packet.max_cell_volt = max_cell_volt;
    packet.min_cell_volt = min_cell_volt;
    packet.fault_flags = fault_flags;
    packet.warning_flags = warning_flags;
    packet.firmware_info = firmware_info;
    packet.soc = soc;
    packet.soh = soh;
    packet.balancing_status_cc1 = balancing_status_cc1;
    packet.balancing_status_cc2 = balancing_status_cc2;
    packet.balancing_status_cc3 = balancing_status_cc3;
    packet.balancing_status_cc4 = balancing_status_cc4;
    packet.id = id;
    packet.max_cell_volt_cell_loc = max_cell_volt_cell_loc;
    packet.max_cell_volt_cell_ctr = max_cell_volt_cell_ctr;
    packet.min_cell_volt_cell_loc = min_cell_volt_cell_loc;
    packet.min_cell_volt_cell_ctr = min_cell_volt_cell_ctr;
    packet.max_temp = max_temp;
    packet.max_temp_ntc_loc_cell = max_temp_ntc_loc_cell;
    packet.max_temp_ntc_loc_ctr = max_temp_ntc_loc_ctr;
    packet.min_temp = min_temp;
    packet.min_temp_ntc_loc_cell = min_temp_ntc_loc_cell;
    packet.min_temp_ntc_loc_ctr = min_temp_ntc_loc_ctr;
    packet.bms_state = bms_state;
    packet.relay_precharge = relay_precharge;
    packet.relay_charge = relay_charge;
    packet.relay_negative = relay_negative;
    packet.relay_positive = relay_positive;
    packet.cell_count_series = cell_count_series;
    mav_array_memcpy(packet.cell_voltages, cell_voltages, sizeof(uint16_t)*14);
    mav_array_memcpy(packet.uid_str, uid_str, sizeof(char)*33);
    mav_array_memcpy(packet.temperatures_ntc, temperatures_ntc, sizeof(int8_t)*7);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CAN_BMS_STATUS, (const char *)&packet, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
#endif
}

/**
 * @brief Send a can_bms_status message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_can_bms_status_send_struct(mavlink_channel_t chan, const mavlink_can_bms_status_t* can_bms_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_can_bms_status_send(chan, can_bms_status->id, can_bms_status->firmware_info, can_bms_status->uid_str, can_bms_status->soc, can_bms_status->soh, can_bms_status->capacity, can_bms_status->remaining_capacity, can_bms_status->batt_volt, can_bms_status->batt_curr, can_bms_status->batt_chr_volt, can_bms_status->max_cell_volt, can_bms_status->max_cell_volt_cell_loc, can_bms_status->max_cell_volt_cell_ctr, can_bms_status->min_cell_volt, can_bms_status->min_cell_volt_cell_loc, can_bms_status->min_cell_volt_cell_ctr, can_bms_status->max_temp, can_bms_status->max_temp_ntc_loc_cell, can_bms_status->max_temp_ntc_loc_ctr, can_bms_status->min_temp, can_bms_status->min_temp_ntc_loc_cell, can_bms_status->min_temp_ntc_loc_ctr, can_bms_status->bms_state, can_bms_status->relay_precharge, can_bms_status->relay_charge, can_bms_status->relay_negative, can_bms_status->relay_positive, can_bms_status->balancing_status_cc1, can_bms_status->balancing_status_cc2, can_bms_status->balancing_status_cc3, can_bms_status->balancing_status_cc4, can_bms_status->fault_flags, can_bms_status->warning_flags, can_bms_status->temperatures_ntc, can_bms_status->cell_voltages, can_bms_status->cell_count_series);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CAN_BMS_STATUS, (const char *)can_bms_status, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
#endif
}

#if MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_can_bms_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t id, uint16_t firmware_info, const char *uid_str, uint16_t soc, uint16_t soh, uint32_t capacity, uint32_t remaining_capacity, float batt_volt, float batt_curr, float batt_chr_volt, float max_cell_volt, uint8_t max_cell_volt_cell_loc, uint8_t max_cell_volt_cell_ctr, float min_cell_volt, uint8_t min_cell_volt_cell_loc, uint8_t min_cell_volt_cell_ctr, int8_t max_temp, uint8_t max_temp_ntc_loc_cell, uint8_t max_temp_ntc_loc_ctr, int8_t min_temp, uint8_t min_temp_ntc_loc_cell, uint8_t min_temp_ntc_loc_ctr, uint8_t bms_state, uint8_t relay_precharge, uint8_t relay_charge, uint8_t relay_negative, uint8_t relay_positive, uint16_t balancing_status_cc1, uint16_t balancing_status_cc2, uint16_t balancing_status_cc3, uint16_t balancing_status_cc4, uint32_t fault_flags, uint32_t warning_flags, const int8_t *temperatures_ntc, const uint16_t *cell_voltages, uint8_t cell_count_series)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, capacity);
    _mav_put_uint32_t(buf, 4, remaining_capacity);
    _mav_put_float(buf, 8, batt_volt);
    _mav_put_float(buf, 12, batt_curr);
    _mav_put_float(buf, 16, batt_chr_volt);
    _mav_put_float(buf, 20, max_cell_volt);
    _mav_put_float(buf, 24, min_cell_volt);
    _mav_put_uint32_t(buf, 28, fault_flags);
    _mav_put_uint32_t(buf, 32, warning_flags);
    _mav_put_uint16_t(buf, 36, firmware_info);
    _mav_put_uint16_t(buf, 38, soc);
    _mav_put_uint16_t(buf, 40, soh);
    _mav_put_uint16_t(buf, 42, balancing_status_cc1);
    _mav_put_uint16_t(buf, 44, balancing_status_cc2);
    _mav_put_uint16_t(buf, 46, balancing_status_cc3);
    _mav_put_uint16_t(buf, 48, balancing_status_cc4);
    _mav_put_uint8_t(buf, 78, id);
    _mav_put_uint8_t(buf, 112, max_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 113, max_cell_volt_cell_ctr);
    _mav_put_uint8_t(buf, 114, min_cell_volt_cell_loc);
    _mav_put_uint8_t(buf, 115, min_cell_volt_cell_ctr);
    _mav_put_int8_t(buf, 116, max_temp);
    _mav_put_uint8_t(buf, 117, max_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 118, max_temp_ntc_loc_ctr);
    _mav_put_int8_t(buf, 119, min_temp);
    _mav_put_uint8_t(buf, 120, min_temp_ntc_loc_cell);
    _mav_put_uint8_t(buf, 121, min_temp_ntc_loc_ctr);
    _mav_put_uint8_t(buf, 122, bms_state);
    _mav_put_uint8_t(buf, 123, relay_precharge);
    _mav_put_uint8_t(buf, 124, relay_charge);
    _mav_put_uint8_t(buf, 125, relay_negative);
    _mav_put_uint8_t(buf, 126, relay_positive);
    _mav_put_uint8_t(buf, 134, cell_count_series);
    _mav_put_uint16_t_array(buf, 50, cell_voltages, 14);
    _mav_put_char_array(buf, 79, uid_str, 33);
    _mav_put_int8_t_array(buf, 127, temperatures_ntc, 7);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CAN_BMS_STATUS, buf, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
#else
    mavlink_can_bms_status_t *packet = (mavlink_can_bms_status_t *)msgbuf;
    packet->capacity = capacity;
    packet->remaining_capacity = remaining_capacity;
    packet->batt_volt = batt_volt;
    packet->batt_curr = batt_curr;
    packet->batt_chr_volt = batt_chr_volt;
    packet->max_cell_volt = max_cell_volt;
    packet->min_cell_volt = min_cell_volt;
    packet->fault_flags = fault_flags;
    packet->warning_flags = warning_flags;
    packet->firmware_info = firmware_info;
    packet->soc = soc;
    packet->soh = soh;
    packet->balancing_status_cc1 = balancing_status_cc1;
    packet->balancing_status_cc2 = balancing_status_cc2;
    packet->balancing_status_cc3 = balancing_status_cc3;
    packet->balancing_status_cc4 = balancing_status_cc4;
    packet->id = id;
    packet->max_cell_volt_cell_loc = max_cell_volt_cell_loc;
    packet->max_cell_volt_cell_ctr = max_cell_volt_cell_ctr;
    packet->min_cell_volt_cell_loc = min_cell_volt_cell_loc;
    packet->min_cell_volt_cell_ctr = min_cell_volt_cell_ctr;
    packet->max_temp = max_temp;
    packet->max_temp_ntc_loc_cell = max_temp_ntc_loc_cell;
    packet->max_temp_ntc_loc_ctr = max_temp_ntc_loc_ctr;
    packet->min_temp = min_temp;
    packet->min_temp_ntc_loc_cell = min_temp_ntc_loc_cell;
    packet->min_temp_ntc_loc_ctr = min_temp_ntc_loc_ctr;
    packet->bms_state = bms_state;
    packet->relay_precharge = relay_precharge;
    packet->relay_charge = relay_charge;
    packet->relay_negative = relay_negative;
    packet->relay_positive = relay_positive;
    packet->cell_count_series = cell_count_series;
    mav_array_memcpy(packet->cell_voltages, cell_voltages, sizeof(uint16_t)*14);
    mav_array_memcpy(packet->uid_str, uid_str, sizeof(char)*33);
    mav_array_memcpy(packet->temperatures_ntc, temperatures_ntc, sizeof(int8_t)*7);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CAN_BMS_STATUS, (const char *)packet, MAVLINK_MSG_ID_CAN_BMS_STATUS_MIN_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN, MAVLINK_MSG_ID_CAN_BMS_STATUS_CRC);
#endif
}
#endif

#endif

// MESSAGE CAN_BMS_STATUS UNPACKING


/**
 * @brief Get field id from can_bms_status message
 *
 * @return  Battery ID
 */
static inline uint8_t mavlink_msg_can_bms_status_get_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  78);
}

/**
 * @brief Get field firmware_info from can_bms_status message
 *
 * @return  Firmware version divided by 100
 */
static inline uint16_t mavlink_msg_can_bms_status_get_firmware_info(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  36);
}

/**
 * @brief Get field uid_str from can_bms_status message
 *
 * @return  Unique ID string (ASCII, null-terminated)
 */
static inline uint16_t mavlink_msg_can_bms_status_get_uid_str(const mavlink_message_t* msg, char *uid_str)
{
    return _MAV_RETURN_char_array(msg, uid_str, 33,  79);
}

/**
 * @brief Get field soc from can_bms_status message
 *
 * @return [%] State of Charge, divide by 10
 */
static inline uint16_t mavlink_msg_can_bms_status_get_soc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  38);
}

/**
 * @brief Get field soh from can_bms_status message
 *
 * @return [%] State of Health, divide by 10
 */
static inline uint16_t mavlink_msg_can_bms_status_get_soh(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  40);
}

/**
 * @brief Get field capacity from can_bms_status message
 *
 * @return [mAh] Nominal capacity, divide by 1000
 */
static inline uint32_t mavlink_msg_can_bms_status_get_capacity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field remaining_capacity from can_bms_status message
 *
 * @return [mAh] Remaining capacity, divide by 1000
 */
static inline uint32_t mavlink_msg_can_bms_status_get_remaining_capacity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field batt_volt from can_bms_status message
 *
 * @return [V] Battery voltage, divide by 1000
 */
static inline float mavlink_msg_can_bms_status_get_batt_volt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field batt_curr from can_bms_status message
 *
 * @return [A] Battery current, divide by 1000 then subtract 1500
 */
static inline float mavlink_msg_can_bms_status_get_batt_curr(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field batt_chr_volt from can_bms_status message
 *
 * @return [V] Charger voltage, divide by 100
 */
static inline float mavlink_msg_can_bms_status_get_batt_chr_volt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field max_cell_volt from can_bms_status message
 *
 * @return [V] Max cell voltage, divide by 1000
 */
static inline float mavlink_msg_can_bms_status_get_max_cell_volt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Get field max_cell_volt_cell_loc from can_bms_status message
 *
 * @return  Location of max voltage cell
 */
static inline uint8_t mavlink_msg_can_bms_status_get_max_cell_volt_cell_loc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  112);
}

/**
 * @brief Get field max_cell_volt_cell_ctr from can_bms_status message
 *
 * @return  Count of cells with max voltage
 */
static inline uint8_t mavlink_msg_can_bms_status_get_max_cell_volt_cell_ctr(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  113);
}

/**
 * @brief Get field min_cell_volt from can_bms_status message
 *
 * @return [V] Min cell voltage, divide by 1000
 */
static inline float mavlink_msg_can_bms_status_get_min_cell_volt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field min_cell_volt_cell_loc from can_bms_status message
 *
 * @return  Location of min voltage cell
 */
static inline uint8_t mavlink_msg_can_bms_status_get_min_cell_volt_cell_loc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  114);
}

/**
 * @brief Get field min_cell_volt_cell_ctr from can_bms_status message
 *
 * @return  Count of cells with min voltage
 */
static inline uint8_t mavlink_msg_can_bms_status_get_min_cell_volt_cell_ctr(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  115);
}

/**
 * @brief Get field max_temp from can_bms_status message
 *
 * @return [degC] Max temperature (offset -128)
 */
static inline int8_t mavlink_msg_can_bms_status_get_max_temp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  116);
}

/**
 * @brief Get field max_temp_ntc_loc_cell from can_bms_status message
 *
 * @return  NTC cell for max temp
 */
static inline uint8_t mavlink_msg_can_bms_status_get_max_temp_ntc_loc_cell(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  117);
}

/**
 * @brief Get field max_temp_ntc_loc_ctr from can_bms_status message
 *
 * @return  NTC controller for max temp
 */
static inline uint8_t mavlink_msg_can_bms_status_get_max_temp_ntc_loc_ctr(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  118);
}

/**
 * @brief Get field min_temp from can_bms_status message
 *
 * @return [degC] Min temperature (offset -128)
 */
static inline int8_t mavlink_msg_can_bms_status_get_min_temp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  119);
}

/**
 * @brief Get field min_temp_ntc_loc_cell from can_bms_status message
 *
 * @return  NTC cell for min temp
 */
static inline uint8_t mavlink_msg_can_bms_status_get_min_temp_ntc_loc_cell(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  120);
}

/**
 * @brief Get field min_temp_ntc_loc_ctr from can_bms_status message
 *
 * @return  NTC controller for min temp
 */
static inline uint8_t mavlink_msg_can_bms_status_get_min_temp_ntc_loc_ctr(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  121);
}

/**
 * @brief Get field bms_state from can_bms_status message
 *
 * @return  BMS state
 */
static inline uint8_t mavlink_msg_can_bms_status_get_bms_state(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  122);
}

/**
 * @brief Get field relay_precharge from can_bms_status message
 *
 * @return  Relay precharge status (0/1)
 */
static inline uint8_t mavlink_msg_can_bms_status_get_relay_precharge(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  123);
}

/**
 * @brief Get field relay_charge from can_bms_status message
 *
 * @return  Relay charge status (0/1)
 */
static inline uint8_t mavlink_msg_can_bms_status_get_relay_charge(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  124);
}

/**
 * @brief Get field relay_negative from can_bms_status message
 *
 * @return  Relay negative status (0/1)
 */
static inline uint8_t mavlink_msg_can_bms_status_get_relay_negative(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  125);
}

/**
 * @brief Get field relay_positive from can_bms_status message
 *
 * @return  Relay positive status (0/1)
 */
static inline uint8_t mavlink_msg_can_bms_status_get_relay_positive(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  126);
}

/**
 * @brief Get field balancing_status_cc1 from can_bms_status message
 *
 * @return  Balancing status CC1
 */
static inline uint16_t mavlink_msg_can_bms_status_get_balancing_status_cc1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  42);
}

/**
 * @brief Get field balancing_status_cc2 from can_bms_status message
 *
 * @return  Balancing status CC2
 */
static inline uint16_t mavlink_msg_can_bms_status_get_balancing_status_cc2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  44);
}

/**
 * @brief Get field balancing_status_cc3 from can_bms_status message
 *
 * @return  Balancing status CC3
 */
static inline uint16_t mavlink_msg_can_bms_status_get_balancing_status_cc3(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  46);
}

/**
 * @brief Get field balancing_status_cc4 from can_bms_status message
 *
 * @return  Balancing status CC4
 */
static inline uint16_t mavlink_msg_can_bms_status_get_balancing_status_cc4(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  48);
}

/**
 * @brief Get field fault_flags from can_bms_status message
 *
 * @return  Fault flags
 */
static inline uint32_t mavlink_msg_can_bms_status_get_fault_flags(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  28);
}

/**
 * @brief Get field warning_flags from can_bms_status message
 *
 * @return  Warning flags
 */
static inline uint32_t mavlink_msg_can_bms_status_get_warning_flags(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  32);
}

/**
 * @brief Get field temperatures_ntc from can_bms_status message
 *
 * @return [degC] Temperatures from NTC sensors, offset -128
 */
static inline uint16_t mavlink_msg_can_bms_status_get_temperatures_ntc(const mavlink_message_t* msg, int8_t *temperatures_ntc)
{
    return _MAV_RETURN_int8_t_array(msg, temperatures_ntc, 7,  127);
}

/**
 * @brief Get field cell_voltages from can_bms_status message
 *
 * @return [mV] Cell voltages, raw. 0 = unused.
 */
static inline uint16_t mavlink_msg_can_bms_status_get_cell_voltages(const mavlink_message_t* msg, uint16_t *cell_voltages)
{
    return _MAV_RETURN_uint16_t_array(msg, cell_voltages, 14,  50);
}

/**
 * @brief Get field cell_count_series from can_bms_status message
 *
 * @return  Number of cells in series
 */
static inline uint8_t mavlink_msg_can_bms_status_get_cell_count_series(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  134);
}

/**
 * @brief Decode a can_bms_status message into a struct
 *
 * @param msg The message to decode
 * @param can_bms_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_can_bms_status_decode(const mavlink_message_t* msg, mavlink_can_bms_status_t* can_bms_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    can_bms_status->capacity = mavlink_msg_can_bms_status_get_capacity(msg);
    can_bms_status->remaining_capacity = mavlink_msg_can_bms_status_get_remaining_capacity(msg);
    can_bms_status->batt_volt = mavlink_msg_can_bms_status_get_batt_volt(msg);
    can_bms_status->batt_curr = mavlink_msg_can_bms_status_get_batt_curr(msg);
    can_bms_status->batt_chr_volt = mavlink_msg_can_bms_status_get_batt_chr_volt(msg);
    can_bms_status->max_cell_volt = mavlink_msg_can_bms_status_get_max_cell_volt(msg);
    can_bms_status->min_cell_volt = mavlink_msg_can_bms_status_get_min_cell_volt(msg);
    can_bms_status->fault_flags = mavlink_msg_can_bms_status_get_fault_flags(msg);
    can_bms_status->warning_flags = mavlink_msg_can_bms_status_get_warning_flags(msg);
    can_bms_status->firmware_info = mavlink_msg_can_bms_status_get_firmware_info(msg);
    can_bms_status->soc = mavlink_msg_can_bms_status_get_soc(msg);
    can_bms_status->soh = mavlink_msg_can_bms_status_get_soh(msg);
    can_bms_status->balancing_status_cc1 = mavlink_msg_can_bms_status_get_balancing_status_cc1(msg);
    can_bms_status->balancing_status_cc2 = mavlink_msg_can_bms_status_get_balancing_status_cc2(msg);
    can_bms_status->balancing_status_cc3 = mavlink_msg_can_bms_status_get_balancing_status_cc3(msg);
    can_bms_status->balancing_status_cc4 = mavlink_msg_can_bms_status_get_balancing_status_cc4(msg);
    mavlink_msg_can_bms_status_get_cell_voltages(msg, can_bms_status->cell_voltages);
    can_bms_status->id = mavlink_msg_can_bms_status_get_id(msg);
    mavlink_msg_can_bms_status_get_uid_str(msg, can_bms_status->uid_str);
    can_bms_status->max_cell_volt_cell_loc = mavlink_msg_can_bms_status_get_max_cell_volt_cell_loc(msg);
    can_bms_status->max_cell_volt_cell_ctr = mavlink_msg_can_bms_status_get_max_cell_volt_cell_ctr(msg);
    can_bms_status->min_cell_volt_cell_loc = mavlink_msg_can_bms_status_get_min_cell_volt_cell_loc(msg);
    can_bms_status->min_cell_volt_cell_ctr = mavlink_msg_can_bms_status_get_min_cell_volt_cell_ctr(msg);
    can_bms_status->max_temp = mavlink_msg_can_bms_status_get_max_temp(msg);
    can_bms_status->max_temp_ntc_loc_cell = mavlink_msg_can_bms_status_get_max_temp_ntc_loc_cell(msg);
    can_bms_status->max_temp_ntc_loc_ctr = mavlink_msg_can_bms_status_get_max_temp_ntc_loc_ctr(msg);
    can_bms_status->min_temp = mavlink_msg_can_bms_status_get_min_temp(msg);
    can_bms_status->min_temp_ntc_loc_cell = mavlink_msg_can_bms_status_get_min_temp_ntc_loc_cell(msg);
    can_bms_status->min_temp_ntc_loc_ctr = mavlink_msg_can_bms_status_get_min_temp_ntc_loc_ctr(msg);
    can_bms_status->bms_state = mavlink_msg_can_bms_status_get_bms_state(msg);
    can_bms_status->relay_precharge = mavlink_msg_can_bms_status_get_relay_precharge(msg);
    can_bms_status->relay_charge = mavlink_msg_can_bms_status_get_relay_charge(msg);
    can_bms_status->relay_negative = mavlink_msg_can_bms_status_get_relay_negative(msg);
    can_bms_status->relay_positive = mavlink_msg_can_bms_status_get_relay_positive(msg);
    mavlink_msg_can_bms_status_get_temperatures_ntc(msg, can_bms_status->temperatures_ntc);
    can_bms_status->cell_count_series = mavlink_msg_can_bms_status_get_cell_count_series(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN? msg->len : MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN;
        memset(can_bms_status, 0, MAVLINK_MSG_ID_CAN_BMS_STATUS_LEN);
    memcpy(can_bms_status, _MAV_PAYLOAD(msg), len);
#endif
}
