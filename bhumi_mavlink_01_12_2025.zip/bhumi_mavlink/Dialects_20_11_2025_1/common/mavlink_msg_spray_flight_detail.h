#pragma once
// MESSAGE SPRAY_FLIGHT_DETAIL PACKING

#define MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL 12921


typedef struct __mavlink_spray_flight_detail_t {
 uint32_t time_boot_ms; /*< [ms] Timestamp (time since system boot).*/
 uint32_t flight_time; /*< [ms] Total Flight Time*/
 uint32_t spray_time; /*< [ms] Total Spray Time*/
 float spray_dist; /*< [m] Total Spray Distance*/
 float flight_dist; /*< [m] Total Flight Distance*/
 float spray_area_sqm; /*< [sqm] Total Flight Spray Area Covered in sqm */
 float spray_area_acre; /*< [Acre] Total Flight Spray Area Covered in Acre*/
 float flight_alt; /*< [m] Vehicle Altitude While Flight*/
 float consumed_liquid; /*< [m] consumed liquid while flight*/
} mavlink_spray_flight_detail_t;

#define MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN 36
#define MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN 36
#define MAVLINK_MSG_ID_12921_LEN 36
#define MAVLINK_MSG_ID_12921_MIN_LEN 36

#define MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC 215
#define MAVLINK_MSG_ID_12921_CRC 215



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_SPRAY_FLIGHT_DETAIL { \
    12921, \
    "SPRAY_FLIGHT_DETAIL", \
    9, \
    {  { "time_boot_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_spray_flight_detail_t, time_boot_ms) }, \
         { "flight_time", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_spray_flight_detail_t, flight_time) }, \
         { "spray_time", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_spray_flight_detail_t, spray_time) }, \
         { "spray_dist", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_spray_flight_detail_t, spray_dist) }, \
         { "flight_dist", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_spray_flight_detail_t, flight_dist) }, \
         { "spray_area_sqm", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_spray_flight_detail_t, spray_area_sqm) }, \
         { "spray_area_acre", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_spray_flight_detail_t, spray_area_acre) }, \
         { "flight_alt", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_spray_flight_detail_t, flight_alt) }, \
         { "consumed_liquid", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_spray_flight_detail_t, consumed_liquid) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_SPRAY_FLIGHT_DETAIL { \
    "SPRAY_FLIGHT_DETAIL", \
    9, \
    {  { "time_boot_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_spray_flight_detail_t, time_boot_ms) }, \
         { "flight_time", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_spray_flight_detail_t, flight_time) }, \
         { "spray_time", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_spray_flight_detail_t, spray_time) }, \
         { "spray_dist", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_spray_flight_detail_t, spray_dist) }, \
         { "flight_dist", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_spray_flight_detail_t, flight_dist) }, \
         { "spray_area_sqm", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_spray_flight_detail_t, spray_area_sqm) }, \
         { "spray_area_acre", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_spray_flight_detail_t, spray_area_acre) }, \
         { "flight_alt", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_spray_flight_detail_t, flight_alt) }, \
         { "consumed_liquid", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_spray_flight_detail_t, consumed_liquid) }, \
         } \
}
#endif

/**
 * @brief Pack a spray_flight_detail message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_boot_ms [ms] Timestamp (time since system boot).
 * @param flight_time [ms] Total Flight Time
 * @param spray_time [ms] Total Spray Time
 * @param spray_dist [m] Total Spray Distance
 * @param flight_dist [m] Total Flight Distance
 * @param spray_area_sqm [sqm] Total Flight Spray Area Covered in sqm 
 * @param spray_area_acre [Acre] Total Flight Spray Area Covered in Acre
 * @param flight_alt [m] Vehicle Altitude While Flight
 * @param consumed_liquid [m] consumed liquid while flight
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_spray_flight_detail_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t time_boot_ms, uint32_t flight_time, uint32_t spray_time, float spray_dist, float flight_dist, float spray_area_sqm, float spray_area_acre, float flight_alt, float consumed_liquid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN];
    _mav_put_uint32_t(buf, 0, time_boot_ms);
    _mav_put_uint32_t(buf, 4, flight_time);
    _mav_put_uint32_t(buf, 8, spray_time);
    _mav_put_float(buf, 12, spray_dist);
    _mav_put_float(buf, 16, flight_dist);
    _mav_put_float(buf, 20, spray_area_sqm);
    _mav_put_float(buf, 24, spray_area_acre);
    _mav_put_float(buf, 28, flight_alt);
    _mav_put_float(buf, 32, consumed_liquid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN);
#else
    mavlink_spray_flight_detail_t packet;
    packet.time_boot_ms = time_boot_ms;
    packet.flight_time = flight_time;
    packet.spray_time = spray_time;
    packet.spray_dist = spray_dist;
    packet.flight_dist = flight_dist;
    packet.spray_area_sqm = spray_area_sqm;
    packet.spray_area_acre = spray_area_acre;
    packet.flight_alt = flight_alt;
    packet.consumed_liquid = consumed_liquid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
}

/**
 * @brief Pack a spray_flight_detail message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_boot_ms [ms] Timestamp (time since system boot).
 * @param flight_time [ms] Total Flight Time
 * @param spray_time [ms] Total Spray Time
 * @param spray_dist [m] Total Spray Distance
 * @param flight_dist [m] Total Flight Distance
 * @param spray_area_sqm [sqm] Total Flight Spray Area Covered in sqm 
 * @param spray_area_acre [Acre] Total Flight Spray Area Covered in Acre
 * @param flight_alt [m] Vehicle Altitude While Flight
 * @param consumed_liquid [m] consumed liquid while flight
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_spray_flight_detail_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t time_boot_ms,uint32_t flight_time,uint32_t spray_time,float spray_dist,float flight_dist,float spray_area_sqm,float spray_area_acre,float flight_alt,float consumed_liquid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN];
    _mav_put_uint32_t(buf, 0, time_boot_ms);
    _mav_put_uint32_t(buf, 4, flight_time);
    _mav_put_uint32_t(buf, 8, spray_time);
    _mav_put_float(buf, 12, spray_dist);
    _mav_put_float(buf, 16, flight_dist);
    _mav_put_float(buf, 20, spray_area_sqm);
    _mav_put_float(buf, 24, spray_area_acre);
    _mav_put_float(buf, 28, flight_alt);
    _mav_put_float(buf, 32, consumed_liquid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN);
#else
    mavlink_spray_flight_detail_t packet;
    packet.time_boot_ms = time_boot_ms;
    packet.flight_time = flight_time;
    packet.spray_time = spray_time;
    packet.spray_dist = spray_dist;
    packet.flight_dist = flight_dist;
    packet.spray_area_sqm = spray_area_sqm;
    packet.spray_area_acre = spray_area_acre;
    packet.flight_alt = flight_alt;
    packet.consumed_liquid = consumed_liquid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
}

/**
 * @brief Encode a spray_flight_detail struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param spray_flight_detail C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_spray_flight_detail_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_spray_flight_detail_t* spray_flight_detail)
{
    return mavlink_msg_spray_flight_detail_pack(system_id, component_id, msg, spray_flight_detail->time_boot_ms, spray_flight_detail->flight_time, spray_flight_detail->spray_time, spray_flight_detail->spray_dist, spray_flight_detail->flight_dist, spray_flight_detail->spray_area_sqm, spray_flight_detail->spray_area_acre, spray_flight_detail->flight_alt, spray_flight_detail->consumed_liquid);
}

/**
 * @brief Encode a spray_flight_detail struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param spray_flight_detail C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_spray_flight_detail_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_spray_flight_detail_t* spray_flight_detail)
{
    return mavlink_msg_spray_flight_detail_pack_chan(system_id, component_id, chan, msg, spray_flight_detail->time_boot_ms, spray_flight_detail->flight_time, spray_flight_detail->spray_time, spray_flight_detail->spray_dist, spray_flight_detail->flight_dist, spray_flight_detail->spray_area_sqm, spray_flight_detail->spray_area_acre, spray_flight_detail->flight_alt, spray_flight_detail->consumed_liquid);
}

/**
 * @brief Send a spray_flight_detail message
 * @param chan MAVLink channel to send the message
 *
 * @param time_boot_ms [ms] Timestamp (time since system boot).
 * @param flight_time [ms] Total Flight Time
 * @param spray_time [ms] Total Spray Time
 * @param spray_dist [m] Total Spray Distance
 * @param flight_dist [m] Total Flight Distance
 * @param spray_area_sqm [sqm] Total Flight Spray Area Covered in sqm 
 * @param spray_area_acre [Acre] Total Flight Spray Area Covered in Acre
 * @param flight_alt [m] Vehicle Altitude While Flight
 * @param consumed_liquid [m] consumed liquid while flight
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_spray_flight_detail_send(mavlink_channel_t chan, uint32_t time_boot_ms, uint32_t flight_time, uint32_t spray_time, float spray_dist, float flight_dist, float spray_area_sqm, float spray_area_acre, float flight_alt, float consumed_liquid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN];
    _mav_put_uint32_t(buf, 0, time_boot_ms);
    _mav_put_uint32_t(buf, 4, flight_time);
    _mav_put_uint32_t(buf, 8, spray_time);
    _mav_put_float(buf, 12, spray_dist);
    _mav_put_float(buf, 16, flight_dist);
    _mav_put_float(buf, 20, spray_area_sqm);
    _mav_put_float(buf, 24, spray_area_acre);
    _mav_put_float(buf, 28, flight_alt);
    _mav_put_float(buf, 32, consumed_liquid);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL, buf, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
#else
    mavlink_spray_flight_detail_t packet;
    packet.time_boot_ms = time_boot_ms;
    packet.flight_time = flight_time;
    packet.spray_time = spray_time;
    packet.spray_dist = spray_dist;
    packet.flight_dist = flight_dist;
    packet.spray_area_sqm = spray_area_sqm;
    packet.spray_area_acre = spray_area_acre;
    packet.flight_alt = flight_alt;
    packet.consumed_liquid = consumed_liquid;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL, (const char *)&packet, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
#endif
}

/**
 * @brief Send a spray_flight_detail message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_spray_flight_detail_send_struct(mavlink_channel_t chan, const mavlink_spray_flight_detail_t* spray_flight_detail)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_spray_flight_detail_send(chan, spray_flight_detail->time_boot_ms, spray_flight_detail->flight_time, spray_flight_detail->spray_time, spray_flight_detail->spray_dist, spray_flight_detail->flight_dist, spray_flight_detail->spray_area_sqm, spray_flight_detail->spray_area_acre, spray_flight_detail->flight_alt, spray_flight_detail->consumed_liquid);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL, (const char *)spray_flight_detail, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
#endif
}

#if MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_spray_flight_detail_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t time_boot_ms, uint32_t flight_time, uint32_t spray_time, float spray_dist, float flight_dist, float spray_area_sqm, float spray_area_acre, float flight_alt, float consumed_liquid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, time_boot_ms);
    _mav_put_uint32_t(buf, 4, flight_time);
    _mav_put_uint32_t(buf, 8, spray_time);
    _mav_put_float(buf, 12, spray_dist);
    _mav_put_float(buf, 16, flight_dist);
    _mav_put_float(buf, 20, spray_area_sqm);
    _mav_put_float(buf, 24, spray_area_acre);
    _mav_put_float(buf, 28, flight_alt);
    _mav_put_float(buf, 32, consumed_liquid);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL, buf, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
#else
    mavlink_spray_flight_detail_t *packet = (mavlink_spray_flight_detail_t *)msgbuf;
    packet->time_boot_ms = time_boot_ms;
    packet->flight_time = flight_time;
    packet->spray_time = spray_time;
    packet->spray_dist = spray_dist;
    packet->flight_dist = flight_dist;
    packet->spray_area_sqm = spray_area_sqm;
    packet->spray_area_acre = spray_area_acre;
    packet->flight_alt = flight_alt;
    packet->consumed_liquid = consumed_liquid;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL, (const char *)packet, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_MIN_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_CRC);
#endif
}
#endif

#endif

// MESSAGE SPRAY_FLIGHT_DETAIL UNPACKING


/**
 * @brief Get field time_boot_ms from spray_flight_detail message
 *
 * @return [ms] Timestamp (time since system boot).
 */
static inline uint32_t mavlink_msg_spray_flight_detail_get_time_boot_ms(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field flight_time from spray_flight_detail message
 *
 * @return [ms] Total Flight Time
 */
static inline uint32_t mavlink_msg_spray_flight_detail_get_flight_time(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field spray_time from spray_flight_detail message
 *
 * @return [ms] Total Spray Time
 */
static inline uint32_t mavlink_msg_spray_flight_detail_get_spray_time(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Get field spray_dist from spray_flight_detail message
 *
 * @return [m] Total Spray Distance
 */
static inline float mavlink_msg_spray_flight_detail_get_spray_dist(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field flight_dist from spray_flight_detail message
 *
 * @return [m] Total Flight Distance
 */
static inline float mavlink_msg_spray_flight_detail_get_flight_dist(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field spray_area_sqm from spray_flight_detail message
 *
 * @return [sqm] Total Flight Spray Area Covered in sqm 
 */
static inline float mavlink_msg_spray_flight_detail_get_spray_area_sqm(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Get field spray_area_acre from spray_flight_detail message
 *
 * @return [Acre] Total Flight Spray Area Covered in Acre
 */
static inline float mavlink_msg_spray_flight_detail_get_spray_area_acre(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field flight_alt from spray_flight_detail message
 *
 * @return [m] Vehicle Altitude While Flight
 */
static inline float mavlink_msg_spray_flight_detail_get_flight_alt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  28);
}

/**
 * @brief Get field consumed_liquid from spray_flight_detail message
 *
 * @return [m] consumed liquid while flight
 */
static inline float mavlink_msg_spray_flight_detail_get_consumed_liquid(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  32);
}

/**
 * @brief Decode a spray_flight_detail message into a struct
 *
 * @param msg The message to decode
 * @param spray_flight_detail C-struct to decode the message contents into
 */
static inline void mavlink_msg_spray_flight_detail_decode(const mavlink_message_t* msg, mavlink_spray_flight_detail_t* spray_flight_detail)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    spray_flight_detail->time_boot_ms = mavlink_msg_spray_flight_detail_get_time_boot_ms(msg);
    spray_flight_detail->flight_time = mavlink_msg_spray_flight_detail_get_flight_time(msg);
    spray_flight_detail->spray_time = mavlink_msg_spray_flight_detail_get_spray_time(msg);
    spray_flight_detail->spray_dist = mavlink_msg_spray_flight_detail_get_spray_dist(msg);
    spray_flight_detail->flight_dist = mavlink_msg_spray_flight_detail_get_flight_dist(msg);
    spray_flight_detail->spray_area_sqm = mavlink_msg_spray_flight_detail_get_spray_area_sqm(msg);
    spray_flight_detail->spray_area_acre = mavlink_msg_spray_flight_detail_get_spray_area_acre(msg);
    spray_flight_detail->flight_alt = mavlink_msg_spray_flight_detail_get_flight_alt(msg);
    spray_flight_detail->consumed_liquid = mavlink_msg_spray_flight_detail_get_consumed_liquid(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN? msg->len : MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN;
        memset(spray_flight_detail, 0, MAVLINK_MSG_ID_SPRAY_FLIGHT_DETAIL_LEN);
    memcpy(spray_flight_detail, _MAV_PAYLOAD(msg), len);
#endif
}
