#pragma once
// MESSAGE ACK_FOR_COMMAND PACKING

#define MAVLINK_MSG_ID_ACK_FOR_COMMAND 229


typedef struct __mavlink_ack_for_command_t {
 uint8_t command; /*<  command which ask for ack*/
 uint8_t command_type; /*<  command type which ask for ask*/
 uint8_t ack; /*<  is ack sucess or failed*/
} mavlink_ack_for_command_t;

#define MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN 3
#define MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN 3
#define MAVLINK_MSG_ID_229_LEN 3
#define MAVLINK_MSG_ID_229_MIN_LEN 3

#define MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC 204
#define MAVLINK_MSG_ID_229_CRC 204



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_ACK_FOR_COMMAND { \
    229, \
    "ACK_FOR_COMMAND", \
    3, \
    {  { "command", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_ack_for_command_t, command) }, \
         { "command_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_ack_for_command_t, command_type) }, \
         { "ack", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_ack_for_command_t, ack) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_ACK_FOR_COMMAND { \
    "ACK_FOR_COMMAND", \
    3, \
    {  { "command", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_ack_for_command_t, command) }, \
         { "command_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_ack_for_command_t, command_type) }, \
         { "ack", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_ack_for_command_t, ack) }, \
         } \
}
#endif

/**
 * @brief Pack a ack_for_command message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param command  command which ask for ack
 * @param command_type  command type which ask for ask
 * @param ack  is ack sucess or failed
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ack_for_command_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t command, uint8_t command_type, uint8_t ack)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN];
    _mav_put_uint8_t(buf, 0, command);
    _mav_put_uint8_t(buf, 1, command_type);
    _mav_put_uint8_t(buf, 2, ack);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN);
#else
    mavlink_ack_for_command_t packet;
    packet.command = command;
    packet.command_type = command_type;
    packet.ack = ack;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_ACK_FOR_COMMAND;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
}

/**
 * @brief Pack a ack_for_command message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param command  command which ask for ack
 * @param command_type  command type which ask for ask
 * @param ack  is ack sucess or failed
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ack_for_command_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t command,uint8_t command_type,uint8_t ack)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN];
    _mav_put_uint8_t(buf, 0, command);
    _mav_put_uint8_t(buf, 1, command_type);
    _mav_put_uint8_t(buf, 2, ack);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN);
#else
    mavlink_ack_for_command_t packet;
    packet.command = command;
    packet.command_type = command_type;
    packet.ack = ack;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_ACK_FOR_COMMAND;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
}

/**
 * @brief Encode a ack_for_command struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ack_for_command C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ack_for_command_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ack_for_command_t* ack_for_command)
{
    return mavlink_msg_ack_for_command_pack(system_id, component_id, msg, ack_for_command->command, ack_for_command->command_type, ack_for_command->ack);
}

/**
 * @brief Encode a ack_for_command struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ack_for_command C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ack_for_command_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ack_for_command_t* ack_for_command)
{
    return mavlink_msg_ack_for_command_pack_chan(system_id, component_id, chan, msg, ack_for_command->command, ack_for_command->command_type, ack_for_command->ack);
}

/**
 * @brief Send a ack_for_command message
 * @param chan MAVLink channel to send the message
 *
 * @param command  command which ask for ack
 * @param command_type  command type which ask for ask
 * @param ack  is ack sucess or failed
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ack_for_command_send(mavlink_channel_t chan, uint8_t command, uint8_t command_type, uint8_t ack)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN];
    _mav_put_uint8_t(buf, 0, command);
    _mav_put_uint8_t(buf, 1, command_type);
    _mav_put_uint8_t(buf, 2, ack);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ACK_FOR_COMMAND, buf, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
#else
    mavlink_ack_for_command_t packet;
    packet.command = command;
    packet.command_type = command_type;
    packet.ack = ack;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ACK_FOR_COMMAND, (const char *)&packet, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
#endif
}

/**
 * @brief Send a ack_for_command message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ack_for_command_send_struct(mavlink_channel_t chan, const mavlink_ack_for_command_t* ack_for_command)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ack_for_command_send(chan, ack_for_command->command, ack_for_command->command_type, ack_for_command->ack);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ACK_FOR_COMMAND, (const char *)ack_for_command, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
#endif
}

#if MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ack_for_command_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t command, uint8_t command_type, uint8_t ack)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, command);
    _mav_put_uint8_t(buf, 1, command_type);
    _mav_put_uint8_t(buf, 2, ack);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ACK_FOR_COMMAND, buf, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
#else
    mavlink_ack_for_command_t *packet = (mavlink_ack_for_command_t *)msgbuf;
    packet->command = command;
    packet->command_type = command_type;
    packet->ack = ack;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ACK_FOR_COMMAND, (const char *)packet, MAVLINK_MSG_ID_ACK_FOR_COMMAND_MIN_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN, MAVLINK_MSG_ID_ACK_FOR_COMMAND_CRC);
#endif
}
#endif

#endif

// MESSAGE ACK_FOR_COMMAND UNPACKING


/**
 * @brief Get field command from ack_for_command message
 *
 * @return  command which ask for ack
 */
static inline uint8_t mavlink_msg_ack_for_command_get_command(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field command_type from ack_for_command message
 *
 * @return  command type which ask for ask
 */
static inline uint8_t mavlink_msg_ack_for_command_get_command_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Get field ack from ack_for_command message
 *
 * @return  is ack sucess or failed
 */
static inline uint8_t mavlink_msg_ack_for_command_get_ack(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  2);
}

/**
 * @brief Decode a ack_for_command message into a struct
 *
 * @param msg The message to decode
 * @param ack_for_command C-struct to decode the message contents into
 */
static inline void mavlink_msg_ack_for_command_decode(const mavlink_message_t* msg, mavlink_ack_for_command_t* ack_for_command)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ack_for_command->command = mavlink_msg_ack_for_command_get_command(msg);
    ack_for_command->command_type = mavlink_msg_ack_for_command_get_command_type(msg);
    ack_for_command->ack = mavlink_msg_ack_for_command_get_ack(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN? msg->len : MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN;
        memset(ack_for_command, 0, MAVLINK_MSG_ID_ACK_FOR_COMMAND_LEN);
    memcpy(ack_for_command, _MAV_PAYLOAD(msg), len);
#endif
}
