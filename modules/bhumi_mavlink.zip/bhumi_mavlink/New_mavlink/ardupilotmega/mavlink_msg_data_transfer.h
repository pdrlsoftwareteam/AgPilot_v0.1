#pragma once
// MESSAGE DATA_TRANSFER PACKING

#define MAVLINK_MSG_ID_DATA_TRANSFER 227


typedef struct __mavlink_data_transfer_t {
 uint16_t valid_data_len; /*<  Number of valid data bytes in data_buffer PDRL.*/
 uint8_t data_type; /*<  data type private = 0 , public = 1 PDRL.*/
 uint8_t buffer_index; /*<  Current buffer index PDRL.*/
 uint8_t data_buffer[250]; /*<  Send key buffer in chunk of 250 bytes at time PDRL.*/
} mavlink_data_transfer_t;

#define MAVLINK_MSG_ID_DATA_TRANSFER_LEN 254
#define MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN 254
#define MAVLINK_MSG_ID_227_LEN 254
#define MAVLINK_MSG_ID_227_MIN_LEN 254

#define MAVLINK_MSG_ID_DATA_TRANSFER_CRC 0
#define MAVLINK_MSG_ID_227_CRC 0

#define MAVLINK_MSG_DATA_TRANSFER_FIELD_DATA_BUFFER_LEN 250

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_DATA_TRANSFER { \
    227, \
    "DATA_TRANSFER", \
    4, \
    {  { "data_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_data_transfer_t, data_type) }, \
         { "buffer_index", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_data_transfer_t, buffer_index) }, \
         { "data_buffer", NULL, MAVLINK_TYPE_UINT8_T, 250, 4, offsetof(mavlink_data_transfer_t, data_buffer) }, \
         { "valid_data_len", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_data_transfer_t, valid_data_len) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_DATA_TRANSFER { \
    "DATA_TRANSFER", \
    4, \
    {  { "data_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_data_transfer_t, data_type) }, \
         { "buffer_index", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_data_transfer_t, buffer_index) }, \
         { "data_buffer", NULL, MAVLINK_TYPE_UINT8_T, 250, 4, offsetof(mavlink_data_transfer_t, data_buffer) }, \
         { "valid_data_len", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_data_transfer_t, valid_data_len) }, \
         } \
}
#endif

/**
 * @brief Pack a data_transfer message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param data_type  data type private = 0 , public = 1 PDRL.
 * @param buffer_index  Current buffer index PDRL.
 * @param data_buffer  Send key buffer in chunk of 250 bytes at time PDRL.
 * @param valid_data_len  Number of valid data bytes in data_buffer PDRL.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_data_transfer_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t data_type, uint8_t buffer_index, const uint8_t *data_buffer, uint16_t valid_data_len)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DATA_TRANSFER_LEN];
    _mav_put_uint16_t(buf, 0, valid_data_len);
    _mav_put_uint8_t(buf, 2, data_type);
    _mav_put_uint8_t(buf, 3, buffer_index);
    _mav_put_uint8_t_array(buf, 4, data_buffer, 250);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DATA_TRANSFER_LEN);
#else
    mavlink_data_transfer_t packet;
    packet.valid_data_len = valid_data_len;
    packet.data_type = data_type;
    packet.buffer_index = buffer_index;
    mav_array_memcpy(packet.data_buffer, data_buffer, sizeof(uint8_t)*250);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DATA_TRANSFER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DATA_TRANSFER;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
}

/**
 * @brief Pack a data_transfer message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param data_type  data type private = 0 , public = 1 PDRL.
 * @param buffer_index  Current buffer index PDRL.
 * @param data_buffer  Send key buffer in chunk of 250 bytes at time PDRL.
 * @param valid_data_len  Number of valid data bytes in data_buffer PDRL.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_data_transfer_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t data_type,uint8_t buffer_index,const uint8_t *data_buffer,uint16_t valid_data_len)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DATA_TRANSFER_LEN];
    _mav_put_uint16_t(buf, 0, valid_data_len);
    _mav_put_uint8_t(buf, 2, data_type);
    _mav_put_uint8_t(buf, 3, buffer_index);
    _mav_put_uint8_t_array(buf, 4, data_buffer, 250);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DATA_TRANSFER_LEN);
#else
    mavlink_data_transfer_t packet;
    packet.valid_data_len = valid_data_len;
    packet.data_type = data_type;
    packet.buffer_index = buffer_index;
    mav_array_memcpy(packet.data_buffer, data_buffer, sizeof(uint8_t)*250);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DATA_TRANSFER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DATA_TRANSFER;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
}

/**
 * @brief Encode a data_transfer struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param data_transfer C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_data_transfer_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_data_transfer_t* data_transfer)
{
    return mavlink_msg_data_transfer_pack(system_id, component_id, msg, data_transfer->data_type, data_transfer->buffer_index, data_transfer->data_buffer, data_transfer->valid_data_len);
}

/**
 * @brief Encode a data_transfer struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param data_transfer C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_data_transfer_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_data_transfer_t* data_transfer)
{
    return mavlink_msg_data_transfer_pack_chan(system_id, component_id, chan, msg, data_transfer->data_type, data_transfer->buffer_index, data_transfer->data_buffer, data_transfer->valid_data_len);
}

/**
 * @brief Send a data_transfer message
 * @param chan MAVLink channel to send the message
 *
 * @param data_type  data type private = 0 , public = 1 PDRL.
 * @param buffer_index  Current buffer index PDRL.
 * @param data_buffer  Send key buffer in chunk of 250 bytes at time PDRL.
 * @param valid_data_len  Number of valid data bytes in data_buffer PDRL.
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_data_transfer_send(mavlink_channel_t chan, uint8_t data_type, uint8_t buffer_index, const uint8_t *data_buffer, uint16_t valid_data_len)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DATA_TRANSFER_LEN];
    _mav_put_uint16_t(buf, 0, valid_data_len);
    _mav_put_uint8_t(buf, 2, data_type);
    _mav_put_uint8_t(buf, 3, buffer_index);
    _mav_put_uint8_t_array(buf, 4, data_buffer, 250);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DATA_TRANSFER, buf, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
#else
    mavlink_data_transfer_t packet;
    packet.valid_data_len = valid_data_len;
    packet.data_type = data_type;
    packet.buffer_index = buffer_index;
    mav_array_memcpy(packet.data_buffer, data_buffer, sizeof(uint8_t)*250);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DATA_TRANSFER, (const char *)&packet, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
#endif
}

/**
 * @brief Send a data_transfer message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_data_transfer_send_struct(mavlink_channel_t chan, const mavlink_data_transfer_t* data_transfer)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_data_transfer_send(chan, data_transfer->data_type, data_transfer->buffer_index, data_transfer->data_buffer, data_transfer->valid_data_len);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DATA_TRANSFER, (const char *)data_transfer, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
#endif
}

#if MAVLINK_MSG_ID_DATA_TRANSFER_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_data_transfer_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t data_type, uint8_t buffer_index, const uint8_t *data_buffer, uint16_t valid_data_len)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint16_t(buf, 0, valid_data_len);
    _mav_put_uint8_t(buf, 2, data_type);
    _mav_put_uint8_t(buf, 3, buffer_index);
    _mav_put_uint8_t_array(buf, 4, data_buffer, 250);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DATA_TRANSFER, buf, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
#else
    mavlink_data_transfer_t *packet = (mavlink_data_transfer_t *)msgbuf;
    packet->valid_data_len = valid_data_len;
    packet->data_type = data_type;
    packet->buffer_index = buffer_index;
    mav_array_memcpy(packet->data_buffer, data_buffer, sizeof(uint8_t)*250);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DATA_TRANSFER, (const char *)packet, MAVLINK_MSG_ID_DATA_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_LEN, MAVLINK_MSG_ID_DATA_TRANSFER_CRC);
#endif
}
#endif

#endif

// MESSAGE DATA_TRANSFER UNPACKING


/**
 * @brief Get field data_type from data_transfer message
 *
 * @return  data type private = 0 , public = 1 PDRL.
 */
static inline uint8_t mavlink_msg_data_transfer_get_data_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  2);
}

/**
 * @brief Get field buffer_index from data_transfer message
 *
 * @return  Current buffer index PDRL.
 */
static inline uint8_t mavlink_msg_data_transfer_get_buffer_index(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  3);
}

/**
 * @brief Get field data_buffer from data_transfer message
 *
 * @return  Send key buffer in chunk of 250 bytes at time PDRL.
 */
static inline uint16_t mavlink_msg_data_transfer_get_data_buffer(const mavlink_message_t* msg, uint8_t *data_buffer)
{
    return _MAV_RETURN_uint8_t_array(msg, data_buffer, 250,  4);
}

/**
 * @brief Get field valid_data_len from data_transfer message
 *
 * @return  Number of valid data bytes in data_buffer PDRL.
 */
static inline uint16_t mavlink_msg_data_transfer_get_valid_data_len(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Decode a data_transfer message into a struct
 *
 * @param msg The message to decode
 * @param data_transfer C-struct to decode the message contents into
 */
static inline void mavlink_msg_data_transfer_decode(const mavlink_message_t* msg, mavlink_data_transfer_t* data_transfer)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    data_transfer->valid_data_len = mavlink_msg_data_transfer_get_valid_data_len(msg);
    data_transfer->data_type = mavlink_msg_data_transfer_get_data_type(msg);
    data_transfer->buffer_index = mavlink_msg_data_transfer_get_buffer_index(msg);
    mavlink_msg_data_transfer_get_data_buffer(msg, data_transfer->data_buffer);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_DATA_TRANSFER_LEN? msg->len : MAVLINK_MSG_ID_DATA_TRANSFER_LEN;
        memset(data_transfer, 0, MAVLINK_MSG_ID_DATA_TRANSFER_LEN);
    memcpy(data_transfer, _MAV_PAYLOAD(msg), len);
#endif
}
