#pragma once
// MESSAGE COMMAND_TRANSFER PACKING

#define MAVLINK_MSG_ID_COMMAND_TRANSFER 228


typedef struct __mavlink_command_transfer_t {
 uint64_t data_len; /*<  Data length 0 - 30.*/
 uint64_t item_count; /*<  Item Count  0 - 255.*/
 uint64_t item_offset; /*<  Item Offset 0 - 65535.*/
 uint8_t command; /*<  command from GCS to FC or FC to GCS PDRL.*/
 uint8_t command_type; /*<  0. Requst , 1. Response PDRL.*/
 uint8_t is_ack_required; /*<  0. No Ack required , 1. Ack required PDRL.*/
 uint8_t command_buff[100]; /*<  fixed length command buffer PDRL.*/
} mavlink_command_transfer_t;

#define MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN 127
#define MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN 127
#define MAVLINK_MSG_ID_228_LEN 127
#define MAVLINK_MSG_ID_228_MIN_LEN 127

#define MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC 206
#define MAVLINK_MSG_ID_228_CRC 206

#define MAVLINK_MSG_COMMAND_TRANSFER_FIELD_COMMAND_BUFF_LEN 100

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_COMMAND_TRANSFER { \
    228, \
    "COMMAND_TRANSFER", \
    7, \
    {  { "command", NULL, MAVLINK_TYPE_UINT8_T, 0, 24, offsetof(mavlink_command_transfer_t, command) }, \
         { "command_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 25, offsetof(mavlink_command_transfer_t, command_type) }, \
         { "is_ack_required", NULL, MAVLINK_TYPE_UINT8_T, 0, 26, offsetof(mavlink_command_transfer_t, is_ack_required) }, \
         { "data_len", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_command_transfer_t, data_len) }, \
         { "item_count", NULL, MAVLINK_TYPE_UINT64_T, 0, 8, offsetof(mavlink_command_transfer_t, item_count) }, \
         { "item_offset", NULL, MAVLINK_TYPE_UINT64_T, 0, 16, offsetof(mavlink_command_transfer_t, item_offset) }, \
         { "command_buff", NULL, MAVLINK_TYPE_UINT8_T, 100, 27, offsetof(mavlink_command_transfer_t, command_buff) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_COMMAND_TRANSFER { \
    "COMMAND_TRANSFER", \
    7, \
    {  { "command", NULL, MAVLINK_TYPE_UINT8_T, 0, 24, offsetof(mavlink_command_transfer_t, command) }, \
         { "command_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 25, offsetof(mavlink_command_transfer_t, command_type) }, \
         { "is_ack_required", NULL, MAVLINK_TYPE_UINT8_T, 0, 26, offsetof(mavlink_command_transfer_t, is_ack_required) }, \
         { "data_len", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_command_transfer_t, data_len) }, \
         { "item_count", NULL, MAVLINK_TYPE_UINT64_T, 0, 8, offsetof(mavlink_command_transfer_t, item_count) }, \
         { "item_offset", NULL, MAVLINK_TYPE_UINT64_T, 0, 16, offsetof(mavlink_command_transfer_t, item_offset) }, \
         { "command_buff", NULL, MAVLINK_TYPE_UINT8_T, 100, 27, offsetof(mavlink_command_transfer_t, command_buff) }, \
         } \
}
#endif

/**
 * @brief Pack a command_transfer message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param command  command from GCS to FC or FC to GCS PDRL.
 * @param command_type  0. Requst , 1. Response PDRL.
 * @param is_ack_required  0. No Ack required , 1. Ack required PDRL.
 * @param data_len  Data length 0 - 30.
 * @param item_count  Item Count  0 - 255.
 * @param item_offset  Item Offset 0 - 65535.
 * @param command_buff  fixed length command buffer PDRL.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_command_transfer_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t command, uint8_t command_type, uint8_t is_ack_required, uint64_t data_len, uint64_t item_count, uint64_t item_offset, const uint8_t *command_buff)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN];
    _mav_put_uint64_t(buf, 0, data_len);
    _mav_put_uint64_t(buf, 8, item_count);
    _mav_put_uint64_t(buf, 16, item_offset);
    _mav_put_uint8_t(buf, 24, command);
    _mav_put_uint8_t(buf, 25, command_type);
    _mav_put_uint8_t(buf, 26, is_ack_required);
    _mav_put_uint8_t_array(buf, 27, command_buff, 100);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN);
#else
    mavlink_command_transfer_t packet;
    packet.data_len = data_len;
    packet.item_count = item_count;
    packet.item_offset = item_offset;
    packet.command = command;
    packet.command_type = command_type;
    packet.is_ack_required = is_ack_required;
    mav_array_memcpy(packet.command_buff, command_buff, sizeof(uint8_t)*100);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_COMMAND_TRANSFER;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
}

/**
 * @brief Pack a command_transfer message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param command  command from GCS to FC or FC to GCS PDRL.
 * @param command_type  0. Requst , 1. Response PDRL.
 * @param is_ack_required  0. No Ack required , 1. Ack required PDRL.
 * @param data_len  Data length 0 - 30.
 * @param item_count  Item Count  0 - 255.
 * @param item_offset  Item Offset 0 - 65535.
 * @param command_buff  fixed length command buffer PDRL.
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_command_transfer_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t command,uint8_t command_type,uint8_t is_ack_required,uint64_t data_len,uint64_t item_count,uint64_t item_offset,const uint8_t *command_buff)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN];
    _mav_put_uint64_t(buf, 0, data_len);
    _mav_put_uint64_t(buf, 8, item_count);
    _mav_put_uint64_t(buf, 16, item_offset);
    _mav_put_uint8_t(buf, 24, command);
    _mav_put_uint8_t(buf, 25, command_type);
    _mav_put_uint8_t(buf, 26, is_ack_required);
    _mav_put_uint8_t_array(buf, 27, command_buff, 100);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN);
#else
    mavlink_command_transfer_t packet;
    packet.data_len = data_len;
    packet.item_count = item_count;
    packet.item_offset = item_offset;
    packet.command = command;
    packet.command_type = command_type;
    packet.is_ack_required = is_ack_required;
    mav_array_memcpy(packet.command_buff, command_buff, sizeof(uint8_t)*100);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_COMMAND_TRANSFER;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
}

/**
 * @brief Encode a command_transfer struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param command_transfer C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_command_transfer_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_command_transfer_t* command_transfer)
{
    return mavlink_msg_command_transfer_pack(system_id, component_id, msg, command_transfer->command, command_transfer->command_type, command_transfer->is_ack_required, command_transfer->data_len, command_transfer->item_count, command_transfer->item_offset, command_transfer->command_buff);
}

/**
 * @brief Encode a command_transfer struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param command_transfer C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_command_transfer_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_command_transfer_t* command_transfer)
{
    return mavlink_msg_command_transfer_pack_chan(system_id, component_id, chan, msg, command_transfer->command, command_transfer->command_type, command_transfer->is_ack_required, command_transfer->data_len, command_transfer->item_count, command_transfer->item_offset, command_transfer->command_buff);
}

/**
 * @brief Send a command_transfer message
 * @param chan MAVLink channel to send the message
 *
 * @param command  command from GCS to FC or FC to GCS PDRL.
 * @param command_type  0. Requst , 1. Response PDRL.
 * @param is_ack_required  0. No Ack required , 1. Ack required PDRL.
 * @param data_len  Data length 0 - 30.
 * @param item_count  Item Count  0 - 255.
 * @param item_offset  Item Offset 0 - 65535.
 * @param command_buff  fixed length command buffer PDRL.
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_command_transfer_send(mavlink_channel_t chan, uint8_t command, uint8_t command_type, uint8_t is_ack_required, uint64_t data_len, uint64_t item_count, uint64_t item_offset, const uint8_t *command_buff)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN];
    _mav_put_uint64_t(buf, 0, data_len);
    _mav_put_uint64_t(buf, 8, item_count);
    _mav_put_uint64_t(buf, 16, item_offset);
    _mav_put_uint8_t(buf, 24, command);
    _mav_put_uint8_t(buf, 25, command_type);
    _mav_put_uint8_t(buf, 26, is_ack_required);
    _mav_put_uint8_t_array(buf, 27, command_buff, 100);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COMMAND_TRANSFER, buf, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
#else
    mavlink_command_transfer_t packet;
    packet.data_len = data_len;
    packet.item_count = item_count;
    packet.item_offset = item_offset;
    packet.command = command;
    packet.command_type = command_type;
    packet.is_ack_required = is_ack_required;
    mav_array_memcpy(packet.command_buff, command_buff, sizeof(uint8_t)*100);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COMMAND_TRANSFER, (const char *)&packet, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
#endif
}

/**
 * @brief Send a command_transfer message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_command_transfer_send_struct(mavlink_channel_t chan, const mavlink_command_transfer_t* command_transfer)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_command_transfer_send(chan, command_transfer->command, command_transfer->command_type, command_transfer->is_ack_required, command_transfer->data_len, command_transfer->item_count, command_transfer->item_offset, command_transfer->command_buff);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COMMAND_TRANSFER, (const char *)command_transfer, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
#endif
}

#if MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_command_transfer_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t command, uint8_t command_type, uint8_t is_ack_required, uint64_t data_len, uint64_t item_count, uint64_t item_offset, const uint8_t *command_buff)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint64_t(buf, 0, data_len);
    _mav_put_uint64_t(buf, 8, item_count);
    _mav_put_uint64_t(buf, 16, item_offset);
    _mav_put_uint8_t(buf, 24, command);
    _mav_put_uint8_t(buf, 25, command_type);
    _mav_put_uint8_t(buf, 26, is_ack_required);
    _mav_put_uint8_t_array(buf, 27, command_buff, 100);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COMMAND_TRANSFER, buf, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
#else
    mavlink_command_transfer_t *packet = (mavlink_command_transfer_t *)msgbuf;
    packet->data_len = data_len;
    packet->item_count = item_count;
    packet->item_offset = item_offset;
    packet->command = command;
    packet->command_type = command_type;
    packet->is_ack_required = is_ack_required;
    mav_array_memcpy(packet->command_buff, command_buff, sizeof(uint8_t)*100);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COMMAND_TRANSFER, (const char *)packet, MAVLINK_MSG_ID_COMMAND_TRANSFER_MIN_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN, MAVLINK_MSG_ID_COMMAND_TRANSFER_CRC);
#endif
}
#endif

#endif

// MESSAGE COMMAND_TRANSFER UNPACKING


/**
 * @brief Get field command from command_transfer message
 *
 * @return  command from GCS to FC or FC to GCS PDRL.
 */
static inline uint8_t mavlink_msg_command_transfer_get_command(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  24);
}

/**
 * @brief Get field command_type from command_transfer message
 *
 * @return  0. Requst , 1. Response PDRL.
 */
static inline uint8_t mavlink_msg_command_transfer_get_command_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  25);
}

/**
 * @brief Get field is_ack_required from command_transfer message
 *
 * @return  0. No Ack required , 1. Ack required PDRL.
 */
static inline uint8_t mavlink_msg_command_transfer_get_is_ack_required(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  26);
}

/**
 * @brief Get field data_len from command_transfer message
 *
 * @return  Data length 0 - 30.
 */
static inline uint64_t mavlink_msg_command_transfer_get_data_len(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  0);
}

/**
 * @brief Get field item_count from command_transfer message
 *
 * @return  Item Count  0 - 255.
 */
static inline uint64_t mavlink_msg_command_transfer_get_item_count(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  8);
}

/**
 * @brief Get field item_offset from command_transfer message
 *
 * @return  Item Offset 0 - 65535.
 */
static inline uint64_t mavlink_msg_command_transfer_get_item_offset(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  16);
}

/**
 * @brief Get field command_buff from command_transfer message
 *
 * @return  fixed length command buffer PDRL.
 */
static inline uint16_t mavlink_msg_command_transfer_get_command_buff(const mavlink_message_t* msg, uint8_t *command_buff)
{
    return _MAV_RETURN_uint8_t_array(msg, command_buff, 100,  27);
}

/**
 * @brief Decode a command_transfer message into a struct
 *
 * @param msg The message to decode
 * @param command_transfer C-struct to decode the message contents into
 */
static inline void mavlink_msg_command_transfer_decode(const mavlink_message_t* msg, mavlink_command_transfer_t* command_transfer)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    command_transfer->data_len = mavlink_msg_command_transfer_get_data_len(msg);
    command_transfer->item_count = mavlink_msg_command_transfer_get_item_count(msg);
    command_transfer->item_offset = mavlink_msg_command_transfer_get_item_offset(msg);
    command_transfer->command = mavlink_msg_command_transfer_get_command(msg);
    command_transfer->command_type = mavlink_msg_command_transfer_get_command_type(msg);
    command_transfer->is_ack_required = mavlink_msg_command_transfer_get_is_ack_required(msg);
    mavlink_msg_command_transfer_get_command_buff(msg, command_transfer->command_buff);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN? msg->len : MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN;
        memset(command_transfer, 0, MAVLINK_MSG_ID_COMMAND_TRANSFER_LEN);
    memcpy(command_transfer, _MAV_PAYLOAD(msg), len);
#endif
}
